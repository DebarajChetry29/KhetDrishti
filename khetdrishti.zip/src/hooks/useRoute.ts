import { useState, useEffect } from 'react';

export type AppRoute = '/' | '/app' | '/expert';

export function useRoute() {
  const getNormalizedRoute = (): AppRoute => {
    if (typeof window === 'undefined') return '/';
    const path = window.location.pathname;
    if (path.startsWith('/expert')) return '/expert';
    if (path.startsWith('/app')) return '/app';
    return '/';
  };

  const [currentRoute, setCurrentRoute] = useState<AppRoute>(getNormalizedRoute);

  useEffect(() => {
    const handlePopState = () => {
      setCurrentRoute(getNormalizedRoute());
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (to: AppRoute) => {
    if (typeof window !== 'undefined' && window.location.pathname !== to) {
      window.history.pushState({}, '', to);
      setCurrentRoute(to);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return { currentRoute, navigate };
}
