import Dexie, { Table } from 'dexie';
import { DiagnosticResult } from '../services/rulesEngine';

export type CaseSyncStatus = 'saved_locally' | 'syncing' | 'sent' | 'expert_replied';

export interface ExpertAdvicePayload {
  expertId?: string;
  expertName: string;
  advice: string;
  repliedAt: string;
}

export interface FarmerCase {
  id: string; // Local unique ID or Firestore doc ID
  userId: string;
  farmerPhone?: string;
  crop: 'wheat' | string;
  photoBase64?: string;
  photoSizeKb?: number;
  answers: Record<string, 'yes' | 'no' | 'not_sure'>;
  result: DiagnosticResult;
  status: CaseSyncStatus;
  isEscalated: boolean;
  expertReply?: ExpertAdvicePayload;
  createdAt: string;
  updatedAt: string;
  syncedToFirestore: boolean;
}

export class KhetDrishtiDatabase extends Dexie {
  public cases!: Table<FarmerCase, string>;

  constructor() {
    super('KhetDrishtiDB');
    this.version(1).stores({
      cases: 'id, userId, status, crop, createdAt, isEscalated, syncedToFirestore',
    });
  }
}

export const dbLocal = new KhetDrishtiDatabase();

// Repository helper functions
export async function saveCaseLocally(farmerCase: FarmerCase): Promise<string> {
  await dbLocal.cases.put(farmerCase);
  return farmerCase.id;
}

export async function getAllLocalCases(): Promise<FarmerCase[]> {
  return await dbLocal.cases.orderBy('createdAt').reverse().toArray();
}

export async function getLocalCaseById(id: string): Promise<FarmerCase | undefined> {
  return await dbLocal.cases.get(id);
}

export async function updateLocalCaseStatus(
  id: string,
  status: CaseSyncStatus,
  expertReply?: ExpertAdvicePayload
): Promise<void> {
  const existing = await dbLocal.cases.get(id);
  if (existing) {
    await dbLocal.cases.update(id, {
      status,
      expertReply: expertReply || existing.expertReply,
      updatedAt: new Date().toISOString(),
    });
  }
}

export async function markCaseAsSynced(id: string): Promise<void> {
  await dbLocal.cases.update(id, {
    status: 'sent',
    syncedToFirestore: true,
    updatedAt: new Date().toISOString(),
  });
}
