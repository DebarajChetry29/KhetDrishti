import React, { useEffect } from 'react';
import './i18n';
import { useRoute } from './hooks/useRoute';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { PublicWebsite } from './pages/PublicWebsite';
import { FarmerApp } from './pages/FarmerApp';
import { ExpertDashboard } from './pages/ExpertDashboard';
import { testFirestoreConnection, ensureFarmerAuth } from './firebase/config';
import { syncService } from './services/syncService';
import { OfflineIndicator } from './components/OfflineIndicator';

export default function App() {
  const { currentRoute, navigate } = useRoute();

  useEffect(() => {
    // Validate connection to Firestore on boot (Skill invariant)
    testFirestoreConnection();

    // Initialize anonymous auth session & sync pending records
    ensureFarmerAuth()
      .then(() => syncService.syncPendingCases())
      .catch((e) => console.warn('Offline session initialized:', e));
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#FAFAF7] text-[#202722]">
      {/* Top Navigation */}
      <Navbar currentRoute={currentRoute} onNavigate={navigate} />

      {/* Main Content Body */}
      <main className="flex-1">
        {currentRoute === '/' && <PublicWebsite onNavigate={navigate} />}
        {currentRoute === '/app' && <FarmerApp onNavigate={navigate} />}
        {currentRoute === '/expert' && <ExpertDashboard onNavigate={navigate} />}
      </main>

      {/* Persistent Offline Banner when disconnected */}
      <OfflineIndicator />

      {/* Global Footer */}
      <Footer onNavigate={navigate} />
    </div>
  );
}
