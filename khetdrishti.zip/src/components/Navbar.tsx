import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Sprout, Menu, X, ShieldCheck } from 'lucide-react';
import { LanguageSwitcher } from './LanguageSwitcher';
import { PWAInstallButton } from './PWAInstallButton';
import { AppRoute } from '../hooks/useRoute';

interface NavbarProps {
  currentRoute: AppRoute;
  onNavigate: (route: AppRoute) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentRoute, onNavigate }) => {
  const { t } = useTranslation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: t('nav.home'), href: '#overview' },
    { label: t('nav.pilot'), href: '#pilot' },
    { label: t('nav.principles'), href: '#principles' },
    { label: t('nav.faq'), href: '#faq' },
    { label: t('nav.contact'), href: '#contact' },
  ];

  const handleLinkClick = (href: string) => {
    setMobileMenuOpen(false);
    if (currentRoute !== '/') {
      onNavigate('/');
      setTimeout(() => {
        const target = document.querySelector(href);
        target?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const target = document.querySelector(href);
      target?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#071C16]/90 backdrop-blur-md text-[#F4F5EC] border-b border-[#B8E6C8]/15">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 md:gap-8 h-16">
          {/* Brand Wordmark */}
          <button
            type="button"
            onClick={() => onNavigate('/')}
            className="flex items-center gap-2.5 text-left group cursor-pointer whitespace-nowrap shrink-0"
          >
            <div className="w-8 h-8 rounded-lg bg-[#12372A] border border-[#B8F34A]/30 text-[#B8F34A] flex items-center justify-center transition-all group-hover:border-[#B8F34A] group-hover:shadow-[0_0_12px_rgba(184,243,74,0.3)]">
              <Sprout className="w-4 h-4" aria-hidden="true" />
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-[#F4F5EC] block leading-tight font-display group-hover:text-[#B8F34A] transition-colors">
                {t('brand.name')}
              </span>
              <span className="text-[11px] text-[#A5B7AC] font-normal tracking-wide block">
                {t('brand.pilotBadge')}
              </span>
            </div>
          </button>

          {/* Minimalist Top Nav Links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-[#A5B7AC]">
            {navLinks.map((link) => (
              <button
                key={link.href}
                type="button"
                onClick={() => handleLinkClick(link.href)}
                className="hover:text-[#B8F34A] transition-colors cursor-pointer whitespace-nowrap shrink-0 py-1"
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Language switcher + Actions */}
          <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
            <PWAInstallButton />
            <LanguageSwitcher />

            <button
              type="button"
              onClick={() => onNavigate('/app')}
              className={`touch-target-48 px-3.5 py-2 text-xs sm:text-sm font-bold rounded-lg transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 btn-tactile ${
                currentRoute === '/app'
                  ? 'bg-[#B8F34A] text-[#071C16] shadow-[0_0_15px_rgba(184,243,74,0.35)]'
                  : 'bg-[#B8F34A] hover:bg-[#c9f863] text-[#071C16] shadow-[0_0_12px_rgba(184,243,74,0.2)]'
              }`}
            >
              <Sprout className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span className="hidden sm:inline">{t('nav.launchApp')}</span>
              <span className="sm:hidden">{t('brand.name')}</span>
            </button>

            <button
              type="button"
              onClick={() => onNavigate('/expert')}
              className="touch-target-48 hidden md:flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-[#F4F5EC] bg-[#12372A] hover:bg-[#164233] rounded-lg border border-[#B8E6C8]/20 hover:border-[#B8F34A]/40 transition-colors cursor-pointer whitespace-nowrap"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-[#B8F34A]" aria-hidden="true" />
              <span>{t('nav.expertPortal')}</span>
            </button>

            {/* Mobile Hamburger Menu Toggle */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden touch-target-48 p-2 rounded-lg text-[#A5B7AC] hover:text-[#F4F5EC] hover:bg-[#12372A]"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0C2A20] border-t border-[#B8E6C8]/15 px-4 pt-3 pb-5 space-y-2">
          {navLinks.map((link) => (
            <button
              key={link.href}
              type="button"
              onClick={() => handleLinkClick(link.href)}
              className="w-full text-left touch-target-48 px-3 py-2.5 text-sm font-medium text-[#F4F5EC] hover:bg-[#12372A] hover:text-[#B8F34A] rounded-lg transition-colors"
            >
              {link.label}
            </button>
          ))}
          <div className="pt-2 border-t border-[#B8E6C8]/15 flex flex-col gap-2">
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onNavigate('/expert');
              }}
              className="w-full text-left touch-target-48 px-3 py-2 text-sm font-medium text-[#B8E6C8] hover:bg-[#12372A] rounded-lg flex items-center gap-2"
            >
              <ShieldCheck className="w-4 h-4 text-[#B8F34A]" />
              <span>{t('nav.expertPortal')}</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
