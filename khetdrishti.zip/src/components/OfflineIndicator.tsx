import React from 'react';
import { useTranslation } from 'react-i18next';
import { WifiOff, Database } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC = () => {
  const { t } = useTranslation();
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-3 left-3 right-3 sm:left-auto sm:right-4 z-50 max-w-sm bg-white text-[#202722] text-xs font-medium px-4 py-3 rounded-xl shadow-lg border border-[#E3E8E2] flex items-center justify-between gap-3"
    >
      <div className="flex items-center gap-2.5">
        <div className="w-7 h-7 rounded-lg bg-[#E8F0E8] flex items-center justify-center text-[#173B2D] shrink-0">
          <WifiOff className="w-3.5 h-3.5" />
        </div>
        <div>
          <span className="font-semibold text-[#202722] block leading-tight">
            {t('common.offline')}
          </span>
          <span className="text-[11px] text-[#69736C] font-normal">
            IndexedDB storage active · Auto-syncs when online
          </span>
        </div>
      </div>
      <Database className="w-4 h-4 text-[#286C4A] shrink-0" />
    </div>
  );
};
