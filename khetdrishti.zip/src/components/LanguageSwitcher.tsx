import React from 'react';
import { useTranslation } from 'react-i18next';
import { Globe } from 'lucide-react';

interface LanguageSwitcherProps {
  compact?: boolean;
}

export const LanguageSwitcher: React.FC<LanguageSwitcherProps> = ({ compact = false }) => {
  const { i18n } = useTranslation();

  const languages = [
    { code: 'as', label: 'অসমীয়া', short: 'অ' },
    { code: 'hi', label: 'हिन्दी', short: 'हि' },
    { code: 'en', label: 'English', short: 'EN' },
  ];

  const handleLanguageChange = (code: string) => {
    i18n.changeLanguage(code);
  };

  return (
    <div
      className="flex items-center gap-0.5 bg-[#0C2A20] p-1 rounded-lg border border-[#B8E6C8]/15"
      role="group"
      aria-label="Language selection"
    >
      <div className="px-1.5 text-[#A5B7AC] hidden sm:flex items-center text-xs">
        <Globe className="w-3.5 h-3.5" aria-hidden="true" />
      </div>
      {languages.map((lang) => {
        const isActive = i18n.language === lang.code;
        return (
          <button
            key={lang.code}
            type="button"
            onClick={() => handleLanguageChange(lang.code)}
            className={`touch-target-48 px-2.5 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer flex items-center justify-center ${
              isActive
                ? 'bg-[#B8F34A] text-[#071C16] shadow-[0_0_10px_rgba(184,243,74,0.3)]'
                : 'text-[#A5B7AC] hover:text-[#F4F5EC] hover:bg-[#12372A]'
            }`}
            aria-pressed={isActive}
            aria-label={`Switch to ${lang.label}`}
          >
            {compact ? lang.short : lang.label}
          </button>
        );
      })}
    </div>
  );
};
