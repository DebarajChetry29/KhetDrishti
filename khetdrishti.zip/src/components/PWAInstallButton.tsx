import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Download, Share2, X, Smartphone } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { t } = useTranslation();
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // Hide button if already installed as standalone PWA
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className="touch-target-48 px-3 py-1.5 rounded-lg bg-[#12372A] hover:bg-[#164233] border border-[#B8E6C8]/20 hover:border-[#B8F34A]/40 text-[#F4F5EC] text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
        aria-label="Install KhetDrishti to Home Screen"
      >
        <Download className="w-3.5 h-3.5 text-[#B8F34A]" />
        <span className="hidden sm:inline">{t('common.installPWA')}</span>
        <span className="sm:hidden">Install</span>
      </button>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className="touch-target-48 px-3 py-1.5 rounded-lg bg-[#12372A] hover:bg-[#164233] border border-[#B8E6C8]/20 hover:border-[#B8F34A]/40 text-[#A5B7AC] hover:text-[#F4F5EC] text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
          aria-label="How to install on iOS"
        >
          <Share2 className="w-3.5 h-3.5 text-[#B8F34A]" />
          <span>iOS Install</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
            <div className="w-full max-w-sm rounded-xl bg-[#0C2A20] p-6 border border-[#B8E6C8]/25 shadow-2xl text-[#F4F5EC] space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#B8E6C8]/15">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-[#12372A] text-[#B8F34A] border border-[#B8F34A]/30 flex items-center justify-center">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-semibold text-[#F4F5EC]">
                    Install on iPhone / iPad
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowIOSGuide(false)}
                  className="touch-target-48 p-1 text-[#A5B7AC] hover:text-[#F4F5EC] cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-3 text-xs sm:text-sm text-[#A5B7AC] leading-relaxed">
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#12372A] text-[#B8F34A] border border-[#B8F34A]/30 font-semibold flex items-center justify-center shrink-0 text-xs">
                    1
                  </span>
                  <p>
                    Tap the <strong className="text-[#F4F5EC]">Share</strong> button at the bottom of Safari toolbar.
                  </p>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#12372A] text-[#B8F34A] border border-[#B8F34A]/30 font-semibold flex items-center justify-center shrink-0 text-xs">
                    2
                  </span>
                  <p>
                    Scroll down and tap <strong className="text-[#F4F5EC]">Add to Home Screen</strong>.
                  </p>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#12372A] text-[#B8F34A] border border-[#B8F34A]/30 font-semibold flex items-center justify-center shrink-0 text-xs">
                    3
                  </span>
                  <p>
                    Open KhetDrishti from your home screen anytime without an active internet connection!
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="w-full touch-target-48 py-2.5 rounded-lg bg-[#B8F34A] hover:bg-[#c9f863] text-[#071C16] font-bold text-sm transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
