import React from 'react';
import { useTranslation } from 'react-i18next';
import { Sprout, Shield, AlertTriangle } from 'lucide-react';
import { AppRoute } from '../hooks/useRoute';

interface FooterProps {
  onNavigate: (route: AppRoute) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const { t } = useTranslation();

  return (
    <footer className="bg-[#0C2A20] text-[#A5B7AC] border-t border-[#B8E6C8]/15 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pb-8 border-b border-[#B8E6C8]/15">
          <div>
            <div className="flex items-center gap-2.5 text-[#F4F5EC] mb-3">
              <div className="w-8 h-8 rounded-lg bg-[#12372A] border border-[#B8F34A]/30 text-[#B8F34A] flex items-center justify-center font-bold">
                <Sprout className="w-4 h-4" />
              </div>
              <span className="text-lg font-bold tracking-tight font-display">{t('brand.name')}</span>
            </div>
            <p className="text-sm text-[#A5B7AC] leading-relaxed max-w-sm font-normal">
              {t('brand.tagline')}
            </p>
            <div className="mt-4 flex items-center gap-2 text-xs text-[#B8F34A] font-semibold">
              <Shield className="w-4 h-4 shrink-0" />
              <span>{t('brand.pilotBadge')}</span>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-semibold text-[#F4F5EC] uppercase tracking-wider mb-3">
              {t('nav.home')}
            </h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#overview" className="hover:text-[#B8F34A] transition-colors">
                  {t('nav.home')}
                </a>
              </li>
              <li>
                <a href="#pilot" className="hover:text-[#B8F34A] transition-colors">
                  {t('nav.pilot')}
                </a>
              </li>
              <li>
                <a href="#principles" className="hover:text-[#B8F34A] transition-colors">
                  {t('nav.principles')}
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-[#B8F34A] transition-colors">
                  {t('nav.faq')}
                </a>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('/expert')}
                  className="hover:text-[#B8F34A] transition-colors cursor-pointer text-left"
                >
                  {t('nav.expertPortal')}
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-semibold text-[#F4F5EC] uppercase tracking-wider mb-3">
              {t('principles.p6Title')}
            </h4>
            <div className="bg-[#12372A] p-4 rounded-xl border border-[#B8E6C8]/15 text-xs text-[#A5B7AC] leading-relaxed flex items-start gap-3">
              <AlertTriangle className="w-4 h-4 text-[#EAB308] shrink-0 mt-0.5" />
              <p>{t('disclaimer.safety')}</p>
            </div>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#A5B7AC]/80">
          <p>{t('common.footerText')}</p>
          <div className="flex items-center gap-3">
            <span>Nagaon, Assam</span>
            <span aria-hidden="true" className="text-[#B8E6C8]/30">·</span>
            <span>Agriculture Census 2015-16</span>
            <span aria-hidden="true" className="text-[#B8E6C8]/30">·</span>
            <span className="text-[#B8F34A]">Version 1.0 (Pilot)</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
