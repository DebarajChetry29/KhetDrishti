/**
 * Pluggable Image Classifier Hook.
 *
 * Designed to return candidate cause predictions when a model endpoint is connected.
 * In accordance with the pilot specification, this function returns an empty array `[]`
 * for version one. Its output can ONLY add weighted evidence to the rules engine
 * and will NEVER be presented to a farmer as a standalone verdict.
 */

export interface ImageClassificationResult {
  causeId: string;
  confidence: number; // 0 to 1
  featureDetected?: string;
}

export async function classifyImage(
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  _photoBase64: string
): Promise<ImageClassificationResult[]> {
  // Pilot Phase 1: Model endpoint hook is intentionally dormant
  // Future implementation:
  // const response = await fetch('/api/vision-classifier', { ... });
  // return await response.json();
  return [];
}
