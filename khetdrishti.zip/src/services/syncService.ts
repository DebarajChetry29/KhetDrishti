import { doc, setDoc, onSnapshot, collection, query, where, getDoc } from 'firebase/firestore';
import { db, ensureFarmerAuth, handleFirestoreError, OperationType } from '../firebase/config';
import {
  dbLocal,
  getAllLocalCases,
  updateLocalCaseStatus,
  markCaseAsSynced,
  FarmerCase,
} from '../db/indexedDB';

export class SyncService {
  private isSyncing = false;
  private unsubscribeListeners: Map<string, () => void> = new Map();

  /**
   * Syncs all un-synced or pending cases from IndexedDB to Firestore.
   */
  public async syncPendingCases(): Promise<{ syncedCount: number; errors: number }> {
    if (this.isSyncing) return { syncedCount: 0, errors: 0 };
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      return { syncedCount: 0, errors: 0 };
    }

    this.isSyncing = true;
    let syncedCount = 0;
    let errors = 0;

    try {
      const user = await ensureFarmerAuth();
      const localCases = await getAllLocalCases();

      // Filter cases needing synchronization
      const pendingCases = localCases.filter(
        (c) => !c.syncedToFirestore || c.status === 'syncing'
      );

      for (const item of pendingCases) {
        try {
          const docRef = doc(db, 'cases', item.id);

          const payload = {
            id: item.id,
            userId: user.uid,
            farmerPhone: item.farmerPhone || '',
            crop: item.crop,
            photoBase64: item.photoBase64 || '',
            photoSizeKb: item.photoSizeKb || 0,
            answers: item.answers,
            result: {
              candidates: item.result.candidates.map((cand) => ({
                causeId: cand.cause.id,
                causeName: cand.cause.name,
                score: cand.score,
                confidenceLevel: cand.confidenceLevel,
                matchedQuestions: cand.matchedQuestions,
              })),
              isEscalated: item.result.isEscalated,
              escalationReason: item.result.escalationReason,
            },
            status: item.isEscalated ? 'sent' : 'saved_locally',
            isEscalated: item.isEscalated,
            createdAt: item.createdAt,
            updatedAt: new Date().toISOString(),
          };

          await setDoc(docRef, payload, { merge: true });
          await markCaseAsSynced(item.id);
          // Ensure local case userId reflects authenticated uid
          if (item.userId !== user.uid) {
            await dbLocal.cases.update(item.id, { userId: user.uid });
          }
          syncedCount += 1;

          // Set up listener for expert reply if escalated
          if (item.isEscalated) {
            await this.watchCaseReplies(item.id);
          }
        } catch (err) {
          errors += 1;
          console.warn(`Sync error on case ${item.id}:`, err);
        }
      }
    } catch (authErr) {
      console.warn('Sync pending cases skipped (Auth unavailable):', authErr);
    } finally {
      this.isSyncing = false;
    }

    return { syncedCount, errors };
  }

  /**
   * Watches a specific case for expert advice and synchronizes it to IndexedDB.
   * Ensures auth session is active before opening Firestore snapshot listener.
   */
  public async watchCaseReplies(caseId: string): Promise<void> {
    if (this.unsubscribeListeners.has(caseId)) return;

    try {
      // Must be authenticated before attaching Firestore listener
      const user = await ensureFarmerAuth().catch(() => null);
      if (!user) {
        console.warn(`Auth pending or offline; deferred reply listener for case ${caseId}`);
        return;
      }

      if (this.unsubscribeListeners.has(caseId)) return;

      const caseDocRef = doc(db, 'cases', caseId);
      const unsub = onSnapshot(
        caseDocRef,
        async (snapshot) => {
          if (snapshot.exists()) {
            const data = snapshot.data();
            if (data.status === 'expert_replied' && data.expertReply) {
              await updateLocalCaseStatus(caseId, 'expert_replied', {
                expertName: data.expertReply.expertName || 'Assam Agriculture Officer',
                advice: data.expertReply.advice || '',
                repliedAt: data.expertReply.repliedAt || new Date().toISOString(),
              });
            }
          }
        },
        (error) => {
          handleFirestoreError(error, OperationType.GET, `cases/${caseId}`);
        }
      );

      this.unsubscribeListeners.set(caseId, unsub);
    } catch (e) {
      console.warn(`Could not attach snapshot listener to case ${caseId}:`, e);
    }
  }

  /**
   * Cleans up all active snapshot listeners
   */
  public cleanup(): void {
    this.unsubscribeListeners.forEach((unsub) => unsub());
    this.unsubscribeListeners.clear();
  }

  /**
   * Saves a public contact message to Firestore
   */
  public async submitContactMessage(message: {
    name: string;
    email: string;
    subject: string;
    message: string;
  }): Promise<void> {
    const id = `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const path = `contactMessages/${id}`;
    try {
      await setDoc(doc(db, 'contactMessages', id), {
        id,
        name: message.name,
        email: message.email,
        subject: message.subject,
        message: message.message,
        createdAt: new Date().toISOString(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  }
}

export const syncService = new SyncService();
