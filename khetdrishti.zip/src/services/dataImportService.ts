import { doc, setDoc, writeBatch } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase/config';
import {
  PILOT_CAUSES,
  PILOT_QUESTIONS,
  PILOT_RULES,
  PILOT_NEXT_STEPS,
  Cause,
  Question,
  Rule,
  NextStep,
} from '../data/knowledgeBase';

export interface ImportValidationResult {
  isValid: boolean;
  detectedType: 'causes' | 'questions' | 'rules' | 'nextSteps' | 'unknown';
  missingColumns: string[];
  foundColumns: string[];
  rowCount: number;
  parsedData: any[];
  error?: string;
}

export const REQUIRED_SCHEMAS = {
  causes: [
    'id',
    'name',
    'assamese_name',
    'hindi_name',
    'scientific_name',
    'risk_level',
    'desc_en',
    'desc_as',
    'desc_hi',
  ],
  questions: [
    'id',
    'order',
    'text_en',
    'text_as',
    'text_hi',
  ],
  rules: [
    'question_id',
    'cause_id',
    'weight',
  ],
  nextSteps: [
    'id',
    'cause_id',
    'order',
    'text_en',
    'text_as',
    'text_hi',
    'reviewed_by',
    'reviewed_on',
  ],
};

/**
 * Parses raw CSV text into header array and rows
 */
export function parseCsvText(csvText: string): { headers: string[]; rows: Record<string, string>[] } {
  const lines = csvText.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length === 0) return { headers: [], rows: [] };

  const parseLine = (line: string): string[] => {
    const result: string[] = [];
    let cur = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (c === '"') {
        inQuotes = !inQuotes;
      } else if (c === ',' && !inQuotes) {
        result.push(cur.trim());
        cur = '';
      } else {
        cur += c;
      }
    }
    result.push(cur.trim());
    return result;
  };

  const headers = parseLine(lines[0]).map((h) => h.toLowerCase().replace(/['"]/g, ''));
  const rows: Record<string, string>[] = [];

  for (let i = 1; i < lines.length; i++) {
    const values = parseLine(lines[i]);
    if (values.length === headers.length) {
      const row: Record<string, string> = {};
      headers.forEach((h, idx) => {
        row[h] = values[idx].replace(/^"|"$/g, '');
      });
      rows.push(row);
    }
  }

  return { headers, rows };
}

/**
 * Validates CSV structure against required agronomic schemas
 */
export function validateImportFile(
  headers: string[],
  rows: Record<string, string>[]
): ImportValidationResult {
  const normHeaders = headers.map((h) => h.toLowerCase().trim());

  // Detect which schema matches best
  let bestMatch: 'causes' | 'questions' | 'rules' | 'nextSteps' | 'unknown' = 'unknown';
  let bestMissing: string[] = [];
  let minMissingCount = Infinity;

  for (const [key, reqCols] of Object.entries(REQUIRED_SCHEMAS)) {
    const missing = reqCols.filter((col) => !normHeaders.includes(col));
    if (missing.length < minMissingCount) {
      minMissingCount = missing.length;
      bestMatch = key as any;
      bestMissing = missing;
    }
  }

  if (minMissingCount === 0) {
    return {
      isValid: true,
      detectedType: bestMatch,
      missingColumns: [],
      foundColumns: normHeaders,
      rowCount: rows.length,
      parsedData: rows,
    };
  }

  return {
    isValid: false,
    detectedType: bestMatch,
    missingColumns: bestMissing,
    foundColumns: normHeaders,
    rowCount: rows.length,
    parsedData: [],
    error: `Missing required columns for [${bestMatch.toUpperCase()}]: ${bestMissing.join(', ')}`,
  };
}

/**
 * Seeds default vetted Nagaon Wheat Pilot knowledge base into Firestore
 */
export async function seedPilotDataToFirestore(): Promise<{
  success: boolean;
  insertedCount: number;
  error?: string;
}> {
  try {
    let count = 0;

    // 1. Seed Crop: Wheat
    await setDoc(doc(db, 'crops', 'wheat'), {
      id: 'wheat',
      name: 'Wheat',
      scientificName: 'Triticum aestivum',
      pilotActive: true,
      locality: 'Nagaon District, Assam',
      icon: 'sprout',
      updatedAt: new Date().toISOString(),
    });
    count += 1;

    // 2. Seed Causes
    for (const cause of PILOT_CAUSES) {
      await setDoc(doc(db, 'causes', cause.id), {
        ...cause,
        updatedAt: new Date().toISOString(),
      });
      count += 1;
    }

    // 3. Seed Questions
    for (const q of PILOT_QUESTIONS) {
      await setDoc(doc(db, 'questions', q.id), {
        ...q,
        cropId: 'wheat',
        updatedAt: new Date().toISOString(),
      });
      count += 1;
    }

    // 4. Seed Rules
    for (let i = 0; i < PILOT_RULES.length; i++) {
      const r = PILOT_RULES[i];
      const ruleId = `rule_${r.questionId}_${r.causeId}`;
      await setDoc(doc(db, 'rules', ruleId), {
        id: ruleId,
        ...r,
        cropId: 'wheat',
        updatedAt: new Date().toISOString(),
      });
      count += 1;
    }

    // 5. Seed Next Steps
    for (const step of PILOT_NEXT_STEPS) {
      await setDoc(doc(db, 'nextSteps', step.id), {
        ...step,
        cropId: 'wheat',
        updatedAt: new Date().toISOString(),
      });
      count += 1;
    }

    return { success: true, insertedCount: count };
  } catch (error) {
    console.error('Seeding Firestore pilot data failed:', error);
    return {
      success: false,
      insertedCount: 0,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

/**
 * Downloads a sample CSV template with exact required columns
 */
export function downloadCsvTemplate(type: 'causes' | 'questions' | 'rules' | 'nextSteps') {
  const reqCols = REQUIRED_SCHEMAS[type];
  let sampleRow = '';

  if (type === 'causes') {
    sampleRow = 'stem_rust,Stem / Black Rust,কলা ৰাষ্ট,काला रतुआ,Puccinia graminis,high,"Reddish-brown pustules on stems and leaf sheaths.","কাণ্ডত মুগা-কলা ৰঙৰ দাগ।","तने पर लाल-भूरे धब्बे।"';
  } else if (type === 'questions') {
    sampleRow = 'q_stem_pustules,8,"Are dark reddish-brown pustules bursting through stem epidermis?","কাণ্ডৰ বাকলি ফাটি মুগা দাগ ওলাইছেনে?","क्या तने की छाल फाड़कर गहरे लाल-भूरे दाने निकल रहे हैं?"';
  } else if (type === 'rules') {
    sampleRow = 'q_stem_pustules,stem_rust,0.90';
  } else if (type === 'nextSteps') {
    sampleRow = 'step_sr_1,stem_rust,1,"Cultural: Remove volunteer barberry and Mahonia bushes near field bunds.","পথাৰৰ কাষৰ বনৰীয়া জোপোহা কাটি পেলাওক।","खेत की मेड़ों के पास से जंगली झाड़ियों को हटाएं।","Dr. B. Bora (AAU / Nagaon KVK)","2026-02-15"';
  }

  const csvContent = `${reqCols.join(',')}\n${sampleRow}\n`;
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `khetdrishti_template_${type}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
