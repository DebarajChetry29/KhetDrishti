/**
 * Browser Web Speech Synthesis service for low-literacy read-aloud support.
 */

class SpeechService {
  private synth: SpeechSynthesis | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private isSpeaking = false;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
    }
  }

  public isAvailable(): boolean {
    return this.synth !== null;
  }

  public speak(
    text: string,
    langCode: 'as' | 'hi' | 'en' | string,
    onStart?: () => void,
    onEnd?: () => void
  ): boolean {
    if (!this.synth) return false;

    this.stop();

    const utterance = new SpeechSynthesisUtterance(text);
    this.currentUtterance = utterance;

    // Map language code to BCP-47 locale
    let targetLocale = 'en-IN';
    if (langCode === 'as') {
      // Assamese locale with Bengali fallback in speech synthesis engines
      targetLocale = 'as-IN';
    } else if (langCode === 'hi') {
      targetLocale = 'hi-IN';
    } else {
      targetLocale = 'en-IN';
    }

    utterance.lang = targetLocale;
    utterance.rate = 0.9; // Slightly slower, calm cadence for accessibility
    utterance.pitch = 1.0;

    utterance.onstart = () => {
      this.isSpeaking = true;
      onStart?.();
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      this.currentUtterance = null;
      onEnd?.();
    };

    utterance.onerror = () => {
      this.isSpeaking = false;
      this.currentUtterance = null;
      onEnd?.();
    };

    try {
      this.synth.speak(utterance);
      return true;
    } catch {
      this.isSpeaking = false;
      return false;
    }
  }

  public stop(): void {
    if (this.synth) {
      this.synth.cancel();
      this.isSpeaking = false;
      this.currentUtterance = null;
    }
  }

  public getIsSpeaking(): boolean {
    return this.isSpeaking;
  }
}

export const speechService = new SpeechService();
