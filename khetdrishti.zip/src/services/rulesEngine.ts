import {
  PILOT_CAUSES,
  PILOT_RULES,
  PILOT_QUESTIONS,
  Cause,
} from '../data/knowledgeBase';
import { ImageClassificationResult } from './imageClassifierHook';

export type UserAnswerValue = 'yes' | 'no' | 'not_sure';
export type UserAnswersMap = Record<string, UserAnswerValue>;

export interface DiagnosisCandidate {
  cause: Cause;
  score: number;
  confidenceLevel: 'high' | 'medium' | 'low';
  matchedQuestions: string[];
}

export type EscalationReason =
  | 'low_confidence'
  | 'too_many_unsure'
  | 'high_risk_flag'
  | 'unsupported_crop'
  | 'none';

export interface DiagnosticResult {
  candidates: DiagnosisCandidate[];
  disclaimer: {
    en: string;
    as: string;
    hi: string;
  };
  isEscalated: boolean;
  escalationReason: EscalationReason;
  escalationMessage: {
    en: string;
    as: string;
    hi: string;
  };
  notSureCount: number;
  totalAnswered: number;
}

// Configurable thresholds for the pilot
export const ENGINE_CONFIG = {
  HIGH_CONFIDENCE_THRESHOLD: 0.70,
  MEDIUM_CONFIDENCE_THRESHOLD: 0.40,
  MAX_NOT_SURE_BEFORE_ESCALATION: 3,
  IMAGE_MODEL_WEIGHT_MULTIPLIER: 0.35, // When vision model is attached
};

export function evaluateCropDiagnostics(
  cropId: string,
  answers: UserAnswersMap,
  imageDetections: ImageClassificationResult[] = []
): DiagnosticResult {
  // 1. Unsupported Crop Escalation Check
  if (cropId !== 'wheat') {
    return {
      candidates: [],
      disclaimer: {
        en: 'This is a possibility, not a final diagnosis.',
        as: 'এইটো এটা সম্ভাৱ্য বিশ্লেষণহে, কোনো চূড়ান্ত নিদান নহয়।',
        hi: 'यह केवल एक संभावना है, कोई अंतिम निदान नहीं।',
      },
      isEscalated: true,
      escalationReason: 'unsupported_crop',
      escalationMessage: {
        en: 'This crop is not yet part of the active Nagaon pilot. Case routed to an agronomist.',
        as: 'এই শস্যটো এতিয়াও নগাঁও পাইলটৰ অংশ নহয়। বিশেষজ্ঞলৈ প্ৰেৰণ কৰা হৈছে।',
        hi: 'यह फसल अभी नगांव पायलट का हिस्सा नहीं है। कृषि वैज्ञानिक को भेजा गया।',
      },
      notSureCount: 0,
      totalAnswered: 0,
    };
  }

  // 2. Count "not sure" responses
  let notSureCount = 0;
  let totalAnswered = 0;
  for (const qId of Object.keys(answers)) {
    totalAnswered += 1;
    if (answers[qId] === 'not_sure') {
      notSureCount += 1;
    }
  }

  // 3. Accumulate raw evidence scores per candidate cause
  const rawScores: Record<string, { score: number; matchedQuestions: string[] }> = {};
  for (const cause of PILOT_CAUSES) {
    rawScores[cause.id] = { score: 0, matchedQuestions: [] };
  }

  for (const rule of PILOT_RULES) {
    const userAnswer = answers[rule.questionId];
    if (!userAnswer) continue;

    if (userAnswer === 'yes') {
      rawScores[rule.causeId].score += rule.weight;
      if (rule.weight > 0) {
        rawScores[rule.causeId].matchedQuestions.push(rule.questionId);
      }
    } else if (userAnswer === 'no') {
      // Negation weight penalty
      if (rule.weight > 0) {
        rawScores[rule.causeId].score -= rule.weight * 0.4;
      }
    }
  }

  // 4. Incorporate image classifier hook if present (never standalone)
  for (const imgResult of imageDetections) {
    if (rawScores[imgResult.causeId]) {
      rawScores[imgResult.causeId].score += imgResult.confidence * ENGINE_CONFIG.IMAGE_MODEL_WEIGHT_MULTIPLIER;
    }
  }

  // 5. Build candidate list (filter score > 0, sort descending)
  const candidates: DiagnosisCandidate[] = [];

  for (const cause of PILOT_CAUSES) {
    const data = rawScores[cause.id];
    // Normalize to 0 - 1 scale
    const normalizedScore = Math.max(0, Math.min(1, data.score));

    if (normalizedScore >= 0.20) {
      let confidenceLevel: 'high' | 'medium' | 'low' = 'low';
      if (normalizedScore >= ENGINE_CONFIG.HIGH_CONFIDENCE_THRESHOLD) {
        confidenceLevel = 'high';
      } else if (normalizedScore >= ENGINE_CONFIG.MEDIUM_CONFIDENCE_THRESHOLD) {
        confidenceLevel = 'medium';
      }

      candidates.push({
        cause,
        score: Math.round(normalizedScore * 100) / 100,
        confidenceLevel,
        matchedQuestions: data.matchedQuestions,
      });
    }
  }

  candidates.sort((a, b) => b.score - a.score);
  // Cap at 1-3 candidates
  const topCandidates = candidates.slice(0, 3);

  // 6. Escalation Rules Check
  let isEscalated = false;
  let escalationReason: EscalationReason = 'none';
  let escalationMessage = {
    en: 'Diagnostic reasoning completed.',
    as: 'লক্ষণ পৰীক্ষা সম্পন্ন হ’ল।',
    hi: 'लक्षण विश्लेषण पूर्ण हुआ।',
  };

  // Rule A: Too many "not sure" answers
  if (notSureCount >= ENGINE_CONFIG.MAX_NOT_SURE_BEFORE_ESCALATION) {
    isEscalated = true;
    escalationReason = 'too_many_unsure';
    escalationMessage = {
      en: 'Multiple symptoms were uncertain ("Not Sure"). Case automatically routed to an agriculture officer to prevent misdiagnosis.',
      as: 'বহুতো লক্ষণত "নিশ্চিত নহয়" উত্তৰ দিয়া হৈছে। ভুল নিদান ৰোধ কৰিবলৈ কৃষি বিশেষজ্ঞলৈ পঠিওৱা হৈছে।',
      hi: 'कई लक्षणों में अनिश्चितता दर्ज हुई है। गलत पहचान से बचने हेतु मामला विशेषज्ञ को भेजा गया है।',
    };
  }
  // Rule B: Low confidence or no matches
  else if (topCandidates.length === 0 || topCandidates[0].confidenceLevel === 'low') {
    isEscalated = true;
    escalationReason = 'low_confidence';
    escalationMessage = {
      en: 'Confidence is low based on the provided symptoms. Case routed to a local expert for photo and field review.',
      as: 'প্ৰদান কৰা লক্ষণসমূহৰ পৰা সম্ভাৱনা স্পষ্ট নহয়। স্পষ্ট বিশ্লেষণৰ বাবে বিশেষজ্ঞলৈ প্ৰেৰণ কৰা হৈছে।',
      hi: 'प्रदान किए गए लक्षणों से स्थिति स्पष्ट नहीं है। फोटो समीक्षा हेतु विशेषज्ञ को भेजा गया।',
    };
  }
  // Rule C: High-risk blight/disease flag (e.g. Yellow Rust or Loose Smut)
  else if (topCandidates.length > 0 && topCandidates[0].cause.riskLevel === 'high') {
    isEscalated = true;
    escalationReason = 'high_risk_flag';
    escalationMessage = {
      en: 'A high-risk condition is suspected (e.g. Stripe Rust or Loose Smut). Automatically shared with KVK Nagaon experts.',
      as: 'উচ্চ বিপদাপন্ন ৰোগৰ (যেনে হালধীয়া ৰাষ্ট বা লুজ স্মাট) সম্ভাৱনা আছে। সতৰ্কতাৰ বাবে বিশেষজ্ঞলৈ পঠিওৱা হ’ল।',
      hi: 'उच्च जोखिम वाले रोग की संभावना है। तत्काल सावधानी हेतु केवीके नगांव को सूचित किया गया।',
    };
  }

  return {
    candidates: topCandidates,
    disclaimer: {
      en: 'This is a possibility, not a final diagnosis.',
      as: 'এইটো এটা সম্ভাৱ্য কাৰণহে, কোনো চূড়ান্ত নিদান নহয়।',
      hi: 'यह केवल एक संभावना है, कोई अंतिम निदान नहीं।',
    },
    isEscalated,
    escalationReason,
    escalationMessage,
    notSureCount,
    totalAnswered,
  };
}
