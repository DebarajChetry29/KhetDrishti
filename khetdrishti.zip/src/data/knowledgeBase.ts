export interface Cause {
  id: string;
  cropId: 'wheat';
  name: string;
  assameseName: string;
  hindiName: string;
  scientificName: string;
  riskLevel: 'low' | 'medium' | 'high';
  description: {
    en: string;
    as: string;
    hi: string;
  };
}

export interface Question {
  id: string;
  order: number;
  iconName: 'stripe' | 'spot' | 'dust' | 'soot' | 'smell' | 'yellow_tip' | 'pale_band' | 'blight';
  text: {
    en: string;
    as: string;
    hi: string;
  };
  helpText?: {
    en: string;
    as: string;
    hi: string;
  };
}

export interface Rule {
  questionId: string;
  causeId: string;
  weight: number; // positive weight for 'yes', negative for 'no'
}

export interface NextStep {
  id: string;
  causeId: string;
  order: number;
  isChemical: boolean;
  reviewedBy: string;
  reviewedOn: string;
  isPlaceholder?: boolean;
  text: {
    en: string;
    as: string;
    hi: string;
  };
}

export const PILOT_CAUSES: Cause[] = [
  {
    id: 'yellow_rust',
    cropId: 'wheat',
    name: 'Yellow / Stripe Rust',
    assameseName: 'হালধীয়া বা ফিটা ৰাষ্ট',
    hindiName: 'पीला रतुआ / स्ट्राइप रस्ट',
    scientificName: 'Puccinia striiformis',
    riskLevel: 'high',
    description: {
      en: 'Fungal disease characterized by yellow-orange powdery pustules arranged in parallel stripes along leaf veins.',
      as: 'পাতৰ সিৰাৰ সমান্তৰালকৈ হালধীয়া-কমলা ৰঙৰ গুড়িৰ দৰে দাগ দেখা পোৱা ভেঁকুৰজনিত ৰোগ।',
      hi: 'पत्तियों की नसों के समानांतर पीली-नारंगी धारियों में उभरे हुए पाउडर जैसे धब्बे।',
    },
  },
  {
    id: 'brown_rust',
    cropId: 'wheat',
    name: 'Brown / Leaf Rust',
    assameseName: 'মুগা বা পাতৰ ৰাষ্ট',
    hindiName: 'भूरा रतुआ / लीफ रस्ट',
    scientificName: 'Puccinia triticina',
    riskLevel: 'medium',
    description: {
      en: 'Scattered oval or circular brown-orange pustules predominantly on the upper leaf blade surface.',
      as: 'পাতৰ ওপৰৰ পিঠিত ঘূৰণীয়া বা ডিম্বাকৃতিৰ মুগা-কমলা ৰঙৰ দাগ বিয়পি পৰে।',
      hi: 'पत्ती की ऊपरी सतह पर बिखरे हुए गोल या अंडाकार भूरे-नारंगी धब्बे।',
    },
  },
  {
    id: 'powdery_mildew',
    cropId: 'wheat',
    name: 'Powdery Mildew',
    assameseName: 'পাউদাৰী মিল্ডিউ',
    hindiName: 'चूर्णी फफूंद (पाउडरी मिल्ड्यू)',
    scientificName: 'Blumeria graminis',
    riskLevel: 'medium',
    description: {
      en: 'White or grayish-white powdery fungal growth spreading across the lower leaves, stems, and leaf sheaths.',
      as: 'তলৰ পাত আৰু কাণ্ডৰ ওপৰত বগা বা ছাইৰঙী পাউদাৰৰ দৰে ভেঁকুৰৰ চামনি পৰে।',
      hi: 'निचली पत्तियों और तनों पर सफेद या धूसर रंग का चूर्ण जैसा कवक जाल फैल जाता है।',
    },
  },
  {
    id: 'loose_smut',
    cropId: 'wheat',
    name: 'Loose Smut',
    assameseName: 'লুজ স্মাট (কলা পোৰা ৰোগ)',
    hindiName: 'खुला कंडुआ (लूज स्मट)',
    scientificName: 'Ustilago tritici',
    riskLevel: 'high',
    description: {
      en: 'Entire wheat head or spikelet is transformed into a mass of black olive-green powdery spores.',
      as: 'ঘেঁহুৰ শীৰ্ষভাগ সম্পূৰ্ণৰূপে কলা গুড়ি বা ধূলিৰ দৰে ৰেণুলৈ ৰূপান্তৰিত হয়।',
      hi: 'गेहूं की पूरी बाली काले पाउडर जैसे बीजाणुओं के गुच्छे में बदल जाती है।',
    },
  },
  {
    id: 'karnal_bunt',
    cropId: 'wheat',
    name: 'Karnal Bunt',
    assameseName: 'কাৰ্নাল বাণ্ট',
    hindiName: 'करनाल बंट',
    scientificName: 'Tilletia indica',
    riskLevel: 'high',
    description: {
      en: 'Partial browning or blackening of individual grains emitting a characteristic rotten-fish odor.',
      as: 'ঘেঁহুৰ দানাবোৰ আংশিকভাৱে কলা পৰি যায় আৰু গেলিব ধৰা মাছৰ দৰে এক বিশেষ দুৰ্গন্ধ ওলায়।',
      hi: 'दानों का आंशिक रूप से काला पड़ना और सड़ी हुई मछली जैसी विशेष गंध आना।',
    },
  },
  {
    id: 'nitrogen_deficiency',
    cropId: 'wheat',
    name: 'Nitrogen Deficiency',
    assameseName: 'নাইট্ৰ’জেনৰ অভাৱ',
    hindiName: 'नाइट्रोजन की कमी',
    scientificName: 'Abiotic / Nutrient',
    riskLevel: 'low',
    description: {
      en: 'General yellowing (chlorosis) beginning from the tips of older bottom leaves progressing in a V-shape.',
      as: 'তলৰ পুৰণি পাতবোৰৰ আগভাগৰ পৰা ভি (V) আকৃতিৰে হালধীয়া পৰি আহে।',
      hi: 'निचली पुरानी पत्तियों की नोक से शुरू होकर वी (V) आकार में पीलापन फैलना।',
    },
  },
  {
    id: 'zinc_deficiency',
    cropId: 'wheat',
    name: 'Zinc Micronutrient Deficiency',
    assameseName: 'জিংক বা দস্তাৰ অভাৱ',
    hindiName: 'जिंक (जस्ता) की कमी',
    scientificName: 'Abiotic / Micronutrient',
    riskLevel: 'low',
    description: {
      en: 'Bleached whitish or light brown bands along the middle area of emerging younger wheat leaves.',
      as: 'নতুনকৈ ওলোৱা কুমলীয়া পাতৰ মাজভাগত বগা বা পাতল মুগা ৰঙৰ পটি দেখা দিয়ে।',
      hi: 'गेहूं की नई पत्तियों के मध्य भाग में सफेद या हल्के भूरे रंग की पट्टियां बनना।',
    },
  },
];

export const PILOT_QUESTIONS: Question[] = [
  {
    id: 'q_yellow_stripes',
    order: 1,
    iconName: 'stripe',
    text: {
      en: 'Are there bright yellow powdery pustules arranged in parallel stripes on the leaves?',
      as: 'পাতৰ ওপৰত সিৰাৰ সমান্তৰালকৈ হালধীয়া গুড়িৰ দৰে দীঘলীয়া দাগ বা ফিটা দেখা গৈছে নেকি?',
      hi: 'क्या पत्तियों पर नसों के साथ-साथ समानांतर धारियों में पीले पाउडर जैसे दाने दिखाई दे रहे हैं?',
    },
    helpText: {
      en: 'Gently rub the leaf with a white cloth or thumb — if yellow powder sticks, this is positive.',
      as: 'বুঢ়া আঙুলিৰে ঘঁহি চাওক — যদি হালধীয়া গুড়ি লাগি আহে, তেন্তে ই ধনাত্মক।',
      hi: 'अंगूठे से हल्के से छुएं — यदि पीला पाउडर उंगली पर लग जाता है तो यह स्पष्ट संकेत है।',
    },
  },
  {
    id: 'q_brown_pustules',
    order: 2,
    iconName: 'spot',
    text: {
      en: 'Are there small, scattered orange or brown oval pustules on the upper leaf surface?',
      as: 'পাতৰ ওপৰৰ পিঠিত সিঁচৰতি হৈ থকা সৰু সৰু মুগা বা কমলা ৰঙৰ ঘূৰণীয়া দাগ আছে নেকি?',
      hi: 'क्या पत्ती की ऊपरी सतह पर छोटे, बिखरे हुए नारंगी या भूरे रंग के धब्बे हैं?',
    },
  },
  {
    id: 'q_powdery_surface',
    order: 3,
    iconName: 'dust',
    text: {
      en: 'Is there a white or grayish fluffy fungal powder coating the lower leaves or stems?',
      as: 'তলৰ পাত বা কাণ্ডত বগা বা ছাইৰঙী কপাহী পাউদাৰৰ দৰে কিবা চামনি পৰিছে নেকি?',
      hi: 'क्या निचली पत्तियों या तने पर सफेद या धूसर रंग का रुई जैसा पाउडर लगा हुआ है?',
    },
  },
  {
    id: 'q_black_ear_head',
    order: 4,
    iconName: 'soot',
    text: {
      en: 'Has the wheat head or spikelet turned into black, soot-like powder?',
      as: 'ঘেঁহুৰ শীৰ্ষভাগ বা দানাবোৰ কলা ধূলি বা আঙেৰুৱা গুড়িলৈ সলনি হৈছে নেকি?',
      hi: 'क्या गेहूं की बाली या दाने काले कालिख जैसे पाउडर में बदल गए हैं?',
    },
  },
  {
    id: 'q_fishy_smell',
    order: 5,
    iconName: 'smell',
    text: {
      en: 'Do damaged grains emit an unpleasant, rotten-fish odor when crushed?',
      as: 'আক্ৰান্ত দানাবোৰ ভাঙি চালে গেলিব ধৰা মাছৰ দৰে কিবা বেয়া গোন্ধ ওলাই নেকি?',
      hi: 'क्या प्रभावित दानों को मसलने पर सड़ी हुई मछली जैसी दुर्गंध आती है?',
    },
  },
  {
    id: 'q_yellow_tip_v',
    order: 6,
    iconName: 'yellow_tip',
    text: {
      en: 'Are the bottom older leaves turning yellow starting from the leaf tips in a V-shape?',
      as: 'তলৰ পুৰণি পাতবোৰৰ আগভাগৰ পৰা ভি (V) আকৃতি লৈ পাতবোৰ হালধীয়া পৰিছে নেকি?',
      hi: 'क्या निचली पुरानी पत्तियां नोक से शुरू होकर वी (V) आकार में पीली पड़ रही हैं?',
    },
  },
  {
    id: 'q_bleached_bands',
    order: 7,
    iconName: 'pale_band',
    text: {
      en: 'Are there bleached whitish or light brown bands in the middle of young leaves?',
      as: 'নতুন কুমলীয়া পাতবোৰৰ মাজভাগত বগা বা শেঁতা মুগা ৰঙৰ দাগ দেখা গৈছে নেকি?',
      hi: 'क्या नई पत्तियों के मध्य भाग में सफेद या हल्के भूरे रंग की चौड़ी पट्टियां दिखाई दे रही हैं?',
    },
  },
];

export const PILOT_RULES: Rule[] = [
  // Yellow Rust
  { questionId: 'q_yellow_stripes', causeId: 'yellow_rust', weight: 0.85 },
  { questionId: 'q_brown_pustules', causeId: 'yellow_rust', weight: -0.2 },
  { questionId: 'q_yellow_tip_v', causeId: 'yellow_rust', weight: -0.3 },

  // Brown Rust
  { questionId: 'q_brown_pustules', causeId: 'brown_rust', weight: 0.8 },
  { questionId: 'q_yellow_stripes', causeId: 'brown_rust', weight: -0.25 },

  // Powdery Mildew
  { questionId: 'q_powdery_surface', causeId: 'powdery_mildew', weight: 0.85 },
  { questionId: 'q_yellow_stripes', causeId: 'powdery_mildew', weight: -0.2 },

  // Loose Smut
  { questionId: 'q_black_ear_head', causeId: 'loose_smut', weight: 0.95 },
  { questionId: 'q_fishy_smell', causeId: 'loose_smut', weight: -0.1 },

  // Karnal Bunt
  { questionId: 'q_fishy_smell', causeId: 'karnal_bunt', weight: 0.85 },
  { questionId: 'q_black_ear_head', causeId: 'karnal_bunt', weight: 0.3 },

  // Nitrogen Deficiency
  { questionId: 'q_yellow_tip_v', causeId: 'nitrogen_deficiency', weight: 0.85 },
  { questionId: 'q_yellow_stripes', causeId: 'nitrogen_deficiency', weight: -0.4 },

  // Zinc Deficiency
  { questionId: 'q_bleached_bands', causeId: 'zinc_deficiency', weight: 0.85 },
  { questionId: 'q_yellow_stripes', causeId: 'zinc_deficiency', weight: -0.3 },
];

export const PILOT_NEXT_STEPS: NextStep[] = [
  // Yellow Rust steps
  {
    id: 'step_yr_1',
    causeId: 'yellow_rust',
    order: 1,
    isChemical: false,
    reviewedBy: 'Dr. B. Bora (Assam Agricultural University / Nagaon KVK)',
    reviewedOn: '2026-02-15',
    text: {
      en: 'Cultural: Avoid excess nitrogen fertilization which promotes lush, susceptible foliage. Ensure adequate spacing and ditch drainage to reduce canopy humidity.',
      as: 'কৃষি পদ্ধতি: অতিমাত্ৰা ইউৰিয়া ব্যৱহাৰ নকৰিব, কাৰণ ই ৰোগ বৃদ্ধিত সহায় কৰে। পথাৰত পানী জমা হ’বলৈ নিদিব আৰু বতাহ চলাচলৰ সুবিধা ৰাখক।',
      hi: 'कृषि उपाय: अत्यधिक यूरिया का उपयोग न करें जिससे पत्तियां अधिक कोमल होकर रोग पकड़ती हैं। खेत में जल निकासी सुनिश्चित करें।',
    },
  },
  {
    id: 'step_yr_2',
    causeId: 'yellow_rust',
    order: 2,
    isChemical: false,
    reviewedBy: 'Dr. B. Bora (Assam Agricultural University / Nagaon KVK)',
    reviewedOn: '2026-02-15',
    text: {
      en: 'Preventive: Mark the affected patch. If disease spreads across multiple rows within 48 hours, immediately notify your local Nagaon Agricultural Extension Officer.',
      as: 'সাৱধানতা: আক্ৰান্ত ঠাইখণ্ড চিনাক্ত কৰক। যদি ৪৮ ঘণ্টাৰ ভিতৰত বেছি পথাৰত বিয়পে, পলম নকৰি স্থানীয় কৃষি সম্প্ৰসাৰণ বিষয়াৰ পৰামৰ্শ লওক।',
      hi: 'सतर्कता: प्रभावित हिस्से को चिह्नित करें। यदि 48 घंटों में फैलाव बढ़ता है, तो तुरंत अपने स्थानीय कृषि प्रसार अधिकारी से संपर्क करें।',
    },
  },

  // Brown Rust steps
  {
    id: 'step_br_1',
    causeId: 'brown_rust',
    order: 1,
    isChemical: false,
    reviewedBy: 'Dr. B. Bora (Assam Agricultural University / Nagaon KVK)',
    reviewedOn: '2026-02-15',
    text: {
      en: 'Cultural: Remove heavily infected lower leaves where practical in small plots. Maintain clean field bunds free from weed grass hosts.',
      as: 'কৃষি পদ্ধতি: পথাৰৰ আলিবাটৰ ঘাঁহ-বন পৰিষ্কাৰ ৰাখক যাতে ৰোগৰ বীজাণু লুকাই থাকিব নোৱাৰে।',
      hi: 'कृषि उपाय: मेड़ों को खरपतवार मुक्त रखें ताकि रोग के कवक को आश्रय न मिले।',
    },
  },

  // Powdery Mildew steps
  {
    id: 'step_pm_1',
    causeId: 'powdery_mildew',
    order: 1,
    isChemical: false,
    reviewedBy: 'Dr. B. Bora (Assam Agricultural University / Nagaon KVK)',
    reviewedOn: '2026-02-15',
    text: {
      en: 'Cultural: Avoid late-evening overhead sprinkler irrigation. Sunlight penetration and good aeration significantly suppress spore survival.',
      as: 'কৃষি পদ্ধতি: আবেলি বা নিশাৰ ভাগত শস্যৰ ওপৰেৰে পানী নিছিটিব। সূৰ্যৰ ৰশ্মি আৰু মুকলি বতাহে এই ৰোগ প্ৰাকৃতিকভাৱে হ্ৰাস কৰে।',
      hi: 'कृषि उपाय: शाम के समय पत्तियों पर छिड़काव सिंचाई से बचें। खुली धूप और हवा इस फफूंद को कम करती है।',
    },
  },

  // Loose Smut steps
  {
    id: 'step_ls_1',
    causeId: 'loose_smut',
    order: 1,
    isChemical: false,
    reviewedBy: 'Dr. B. Bora (Assam Agricultural University / Nagaon KVK)',
    reviewedOn: '2026-02-15',
    text: {
      en: 'Immediate Action: Carefully cover the infected smutted head with a polythene bag, cut it at the base, and burn or bury it away from the field to prevent wind-borne spore spread.',
      as: 'জৰুৰী পদক্ষেপ: আক্ৰান্ত ক’লা পৰা শীৰ্ষভাগটো সাবধানে প্লাষ্টিকৰ বেগেৰে ঢাকি কাটি পেলাওক আৰু পথাৰৰ পৰা দূৰৈত পুতি থওক যাতে বতাহে ৰেণু বিয়পাব নোৱাৰে।',
      hi: 'तत्काल उपाय: प्रभावित काली बाली को पॉलीथीन बैग से ढंककर सावधानी से काटें और खेत से दूर गड्ढे में दबाएं ताकि बीजाणु हवा से न फैलें।',
    },
  },
  {
    id: 'step_ls_2',
    causeId: 'loose_smut',
    order: 2,
    isChemical: false,
    reviewedBy: 'Dr. B. Bora (Assam Agricultural University / Nagaon KVK)',
    reviewedOn: '2026-02-15',
    text: {
      en: 'Seed Precaution: Never use seeds harvested from this infected crop for next season planting. Future sowing requires certified disease-free treated seed.',
      as: 'বীজ সংৰক্ষণ সতৰ্কতা: এই আক্ৰান্ত শস্যৰ পৰা অহা বীজ অহা বছৰ কেতিয়াও ব্যৱহাৰ নকৰিব। সদায় পৰীক্ষিত বীজ ব্যৱহাৰ কৰক।',
      hi: 'बीज चेतावनी: इस प्रभावित खेत से प्राप्त अनाज को अगली बुवाई के बीज के रूप में कभी उपयोग न करें।',
    },
  },

  // Karnal Bunt steps
  {
    id: 'step_kb_1',
    causeId: 'karnal_bunt',
    order: 1,
    isChemical: false,
    reviewedBy: 'Dr. B. Bora (Assam Agricultural University / Nagaon KVK)',
    reviewedOn: '2026-02-15',
    text: {
      en: 'High-Risk Notice: Karnal Bunt is a regulated fungal issue. Report suspected samples directly to KVK Nagaon for laboratory seed confirmation.',
      as: 'বিশেষ সতৰ্কবাণী: কাৰ্নাল বাণ্ট এটা সংবেদনশীল ৰোগ। পৰীক্ষাগাৰত নিশ্চিতিৰ বাবে নমুনা নগাঁও কেভিকে (KVK) বিশেষজ্ঞক দেখুৱাওক।',
      hi: 'विशेष सतर्कता: यह एक गंभीर रोग है। पुष्टि के लिए प्रभावित दाने केवीके नगांव के विशेषज्ञ को दिखाएं।',
    },
  },

  // Nitrogen Deficiency steps
  {
    id: 'step_nd_1',
    causeId: 'nitrogen_deficiency',
    order: 1,
    isChemical: false,
    reviewedBy: 'Dr. B. Bora (Assam Agricultural University / Nagaon KVK)',
    reviewedOn: '2026-02-15',
    text: {
      en: 'Nutrient Practice: Apply well-rotted farmyard manure (FYM) or split dose of balanced nitrogen only after soil moisture is adequate. Do not apply fertilizer on dry soil.',
      as: 'সাৰ প্ৰয়োগ: পথাৰত পৰ্যাপ্ত আৰ্দ্ৰতা থকা অৱস্থাতহে সুষম মাত্ৰাত পচন সাৰ বা ইউৰিয়া প্ৰয়োগ কৰক। শুকান মাটিত কেতিয়াও সাৰ নিদিব।',
      hi: 'पोषक तत्व प्रबंधन: मिट्टी में पर्याप्त नमी होने पर ही संतुलित रूप में सड़ा हुआ गोबर या नाइट्रोजन दें। सूखी मिट्टी में खाद न डालें।',
    },
  },

  // Zinc Deficiency steps
  {
    id: 'step_zd_1',
    causeId: 'zinc_deficiency',
    order: 1,
    isChemical: false,
    reviewedBy: 'Dr. B. Bora (Assam Agricultural University / Nagaon KVK)',
    reviewedOn: '2026-02-15',
    text: {
      en: 'Nutrient Practice: Have soil tested for micronutrient status. Organic compost and vermicompost enrich baseline micronutrient availability.',
      as: 'মাটি পৰীক্ষা: কেঁচুসাৰ বা জৈৱিক কম্পোষ্ট ব্যৱহাৰে মাটিৰ জিংকৰ অভাৱ পূৰণ কৰাত সহায় কৰে। মাটি পৰীক্ষা কৰাই লোৱা উত্তম।',
      hi: 'पोषक तत्व प्रबंधन: वर्मीकम्पोस्ट (केंचुआ खाद) का उपयोग सूक्ष्म पोषक तत्वों की आपूर्ति में सहायक होता है। मिट्टी की जांच कराएं।',
    },
  },
];
