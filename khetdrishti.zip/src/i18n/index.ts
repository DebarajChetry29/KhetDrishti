import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import as from './locales/as.json';
import hi from './locales/hi.json';
import en from './locales/en.json';

const savedLang = typeof localStorage !== 'undefined' ? localStorage.getItem('khetdrishti_lang') : null;
const initialLanguage = savedLang || 'as'; // Assamese as default

i18n
  .use(initReactI18next)
  .init({
    resources: {
      as: { translation: as },
      hi: { translation: hi },
      en: { translation: en },
    },
    lng: initialLanguage,
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false, // React already escapes values
    },
  });

// Keep html lang attribute in sync for typography and screen readers
if (typeof document !== 'undefined') {
  document.documentElement.lang = initialLanguage;
}

i18n.on('languageChanged', (lng) => {
  if (typeof document !== 'undefined') {
    document.documentElement.lang = lng;
  }
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem('khetdrishti_lang', lng);
  }
});

export default i18n;
