import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Sprout,
  ShieldAlert,
  WifiOff,
  UserCheck,
  Languages,
  Ban,
  ShieldCheck,
  ChevronDown,
  Camera,
  HelpCircle,
  Sparkles,
  Send,
  CheckCircle2,
  AlertCircle,
  Activity,
  Check,
  Leaf
} from 'lucide-react';
import { AppRoute } from '../hooks/useRoute';
import { syncService } from '../services/syncService';

interface PublicWebsiteProps {
  onNavigate: (route: AppRoute) => void;
}

export const PublicWebsite: React.FC<PublicWebsiteProps> = ({ onNavigate }) => {
  const { t } = useTranslation();

  // Contact form state
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactSubject, setContactSubject] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // FAQ open states
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName.trim() || !contactMessage.trim()) return;

    setIsSubmitting(true);
    try {
      const submission = {
        name: contactName,
        email: contactEmail,
        subject: contactSubject,
        message: contactMessage,
        createdAt: new Date().toISOString(),
      };

      // Try submitting to Firestore
      try {
        await syncService.submitContactMessage(submission);
      } catch (cloudErr) {
        console.warn('Firestore submission offline, queuing locally:', cloudErr);
      }

      // Also persist locally
      const existing = JSON.parse(localStorage.getItem('khetdrishti_contact_messages') || '[]');
      existing.push(submission);
      localStorage.setItem('khetdrishti_contact_messages', JSON.stringify(existing));

      setSubmitSuccess(true);
      setContactName('');
      setContactEmail('');
      setContactSubject('');
      setContactMessage('');
      setTimeout(() => setSubmitSuccess(false), 6000);
    } catch {
      // Local fallback
    } finally {
      setIsSubmitting(false);
    }
  };

  const principlesList = [
    {
      num: '01',
      title: t('principles.p1Title'),
      desc: t('principles.p1Desc'),
      icon: ShieldAlert,
    },
    {
      num: '02',
      title: t('principles.p2Title'),
      desc: t('principles.p2Desc'),
      icon: UserCheck,
    },
    {
      num: '03',
      title: t('principles.p3Title'),
      desc: t('principles.p3Desc'),
      icon: WifiOff,
    },
    {
      num: '04',
      title: t('principles.p4Title'),
      desc: t('principles.p4Desc'),
      icon: Languages,
    },
    {
      num: '05',
      title: t('principles.p5Title'),
      desc: t('principles.p5Desc'),
      icon: Ban,
    },
    {
      num: '06',
      title: t('principles.p6Title'),
      desc: t('principles.p6Desc'),
      icon: ShieldCheck,
    },
  ];

  const workflowSteps = [
    {
      step: '01',
      title: t('workflow.step1Title'),
      desc: t('workflow.step1Desc'),
      icon: Sprout,
    },
    {
      step: '02',
      title: t('workflow.step2Title'),
      desc: t('workflow.step2Desc'),
      icon: Camera,
    },
    {
      step: '03',
      title: t('workflow.step3Title'),
      desc: t('workflow.step3Desc'),
      icon: HelpCircle,
    },
    {
      step: '04',
      title: t('workflow.step4Title'),
      desc: t('workflow.step4Desc'),
      icon: Sparkles,
    },
  ];

  return (
    <div className="space-y-16 sm:space-y-24 pb-20">
      {/* Hero Section */}
      <section id="overview" className="relative pt-12 sm:pt-20 pb-16 bg-[#071C16] text-[#F4F5EC] border-b border-[#B8E6C8]/15 overflow-hidden">
        {/* Atmospheric Ambient Lighting Gradients */}
        <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-[#B8F34A]/5 rounded-full blur-3xl pointer-events-none -translate-y-1/2" />
        <div className="absolute bottom-0 right-10 w-[400px] h-[400px] bg-[#12372A] rounded-full blur-3xl pointer-events-none translate-y-1/3" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
            <div className="lg:col-span-7 space-y-6">
              {/* Pilot Trust Signal */}
              <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#B8F34A] bg-[#12372A] px-3 py-1 rounded-md border border-[#B8F34A]/30">
                <span>{t('brand.pilotBadge')}</span>
                <span aria-hidden="true" className="text-[#A5B7AC]">·</span>
                <span className="text-[#B8E6C8] font-normal">Nagaon Field Pilot</span>
              </div>

              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#F4F5EC] leading-[1.12] font-display" style={{ textWrap: 'balance' }}>
                {t('hero.title')}
              </h1>

              <p className="text-base sm:text-lg text-[#A5B7AC] leading-relaxed max-w-2xl font-normal">
                {t('hero.subtitle')}
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap items-center gap-3.5 pt-2">
                <button
                  type="button"
                  onClick={() => onNavigate('/app')}
                  className="touch-target-48 px-7 py-3.5 bg-[#B8F34A] hover:bg-[#c9f863] text-[#071C16] font-bold rounded-lg transition-all btn-tactile cursor-pointer flex items-center gap-2.5 text-sm sm:text-base shadow-[0_0_20px_rgba(184,243,74,0.3)] hover:shadow-[0_0_28px_rgba(184,243,74,0.45)]"
                >
                  <Sprout className="w-5 h-5 text-[#071C16]" />
                  <span>{t('hero.openAppBtn')}</span>
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate('/expert')}
                  className="touch-target-48 px-6 py-3.5 bg-[#12372A] hover:bg-[#164233] text-[#F4F5EC] hover:text-[#B8F34A] font-medium rounded-lg border border-[#B8E6C8]/25 hover:border-[#B8F34A]/50 transition-all cursor-pointer flex items-center gap-2 text-sm btn-tactile"
                >
                  <ShieldCheck className="w-4 h-4 text-[#B8F34A]" />
                  <span>{t('hero.expertBtn')}</span>
                </button>
              </div>

              {/* Offline note */}
              <div className="flex items-center gap-2 text-xs text-[#A5B7AC] pt-1">
                <div className="w-4 h-4 rounded bg-[#12372A] border border-[#B8E6C8]/20 flex items-center justify-center text-[#B8F34A]">
                  <WifiOff className="w-2.5 h-2.5" />
                </div>
                <span>{t('hero.offlineNotice')}</span>
              </div>
            </div>

            {/* Hero Visual Card: Crop-Health Diagnostic Preview HUD */}
            <div className="lg:col-span-5">
              <div className="bg-[#12372A] border border-[#B8E6C8]/20 rounded-2xl p-6 sm:p-7 shadow-[0_12px_40px_rgba(7,28,22,0.8)] relative overflow-hidden">
                {/* Visual Accent Glow */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-[#B8F34A]/10 rounded-full blur-2xl pointer-events-none" />

                <div className="space-y-4 relative z-10">
                  {/* Header */}
                  <div className="flex items-center justify-between pb-3.5 border-b border-[#B8E6C8]/15">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-[#0C2A20] border border-[#B8F34A]/30 text-[#B8F34A] flex items-center justify-center">
                        <Leaf className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-[#F4F5EC] font-display flex items-center gap-2">
                          <span>{t('app.cropWheat')}</span>
                          <span className="w-1.5 h-1.5 rounded-full bg-[#B8F34A]" />
                        </div>
                        <div className="text-[11px] text-[#A5B7AC]">Triticum aestivum · Nagaon Field Sector</div>
                      </div>
                    </div>
                    <span className="text-xs text-[#B8F34A] font-semibold bg-[#0C2A20] px-2.5 py-1 rounded border border-[#B8F34A]/30">
                      {t('app.cropWheatDesc')}
                    </span>
                  </div>

                  {/* Botanical Graphic Field Container */}
                  <div className="relative rounded-xl overflow-hidden bg-[#0C2A20] border border-[#B8E6C8]/15 p-4 flex flex-col items-center justify-center text-center">
                    <div className="w-full flex items-center justify-between text-[11px] text-[#A5B7AC] mb-2 font-mono">
                      <span>SCAN // 04-STEP PIPELINE</span>
                      <span className="text-[#B8F34A] flex items-center gap-1">
                        <Activity className="w-3 h-3 text-[#B8F34A]" />
                        READY
                      </span>
                    </div>

                    {/* Illustrated Field Specimen Graphic */}
                    <div className="w-full py-4 px-2 flex items-center justify-around bg-gradient-to-b from-[#12372A]/40 to-[#071C16]/60 rounded-lg border border-[#B8E6C8]/10 my-1">
                      <div className="flex flex-col items-center gap-1.5">
                        <div className="w-12 h-12 rounded-xl bg-[#12372A] border border-[#B8F34A]/30 flex items-center justify-center text-[#B8F34A]">
                          <Camera className="w-6 h-6" />
                        </div>
                        <span className="text-[11px] text-[#A5B7AC]">Visual Crop Specimen</span>
                      </div>
                      <div className="h-10 w-px bg-[#B8E6C8]/15" />
                      <div className="flex flex-col items-center gap-1.5">
                        <div className="w-12 h-12 rounded-xl bg-[#12372A] border border-[#B8E6C8]/25 flex items-center justify-center text-[#B8E6C8]">
                          <ShieldCheck className="w-6 h-6" />
                        </div>
                        <span className="text-[11px] text-[#A5B7AC]">AAU Certified Logic</span>
                      </div>
                    </div>
                  </div>

                  {/* Guided Symptom Card Preview */}
                  <div className="bg-[#0C2A20] p-4 rounded-xl border border-[#B8E6C8]/15 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-[#B8F34A] font-semibold uppercase tracking-wider">
                        {t('app.guidedQuestions')} · 4-8 {t('workflow.step3Title')}
                      </div>
                      <span className="text-[11px] text-[#A5B7AC]">Step 3/4</span>
                    </div>
                    <p className="text-sm text-[#F4F5EC] font-medium leading-relaxed">
                      &quot;পাতৰ ওপৰত হালধীয়া বা মুগা দাগ দেখা গৈছে নেকি?&quot;
                    </p>
                    <div className="grid grid-cols-3 gap-2 pt-1">
                      <div className="py-2.5 px-2 text-center bg-[#B8F34A] text-[#071C16] font-bold rounded-lg text-xs shadow-[0_0_10px_rgba(184,243,74,0.3)]">
                        {t('app.yes')}
                      </div>
                      <div className="py-2.5 px-2 text-center bg-[#12372A] text-[#F4F5EC] rounded-lg text-xs border border-[#B8E6C8]/20 font-medium">
                        {t('app.no')}
                      </div>
                      <div className="py-2.5 px-2 text-center bg-[#12372A] text-[#A5B7AC] rounded-lg text-xs border border-[#B8E6C8]/15 font-medium">
                        {t('app.notSure')}
                      </div>
                    </div>
                  </div>

                  {/* Safety Invariant Notice */}
                  <div className="p-3 bg-[#0C2A20]/70 border border-[#B8E6C8]/20 rounded-lg text-xs text-[#B8E6C8] flex items-start gap-2.5">
                    <AlertCircle className="w-4 h-4 text-[#B8F34A] shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold block text-[#F4F5EC]">{t('principles.p1Title')}</span>
                      <span className="text-[#A5B7AC]">&quot;{t('resultsSubtitle', { ns: 'app' })}&quot;</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Assam Agriculture Census Context Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#12372A] text-[#F4F5EC] border border-[#B8E6C8]/15 rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-center gap-6 sm:gap-8 shadow-lg">
          <div className="shrink-0 text-center md:text-left">
            <span className="text-4xl sm:text-5xl font-extrabold text-[#B8F34A] tabular-nums block font-display tracking-tight">
              {t('census.stat')}
            </span>
            <span className="text-xs text-[#A5B7AC] font-semibold uppercase tracking-wider block mt-1">
              Assam Operational Holdings &lt; 2 Hectares
            </span>
          </div>
          <div className="h-px w-full md:h-14 md:w-px bg-[#B8E6C8]/20 shrink-0" aria-hidden="true" />
          <div className="text-sm sm:text-base text-[#A5B7AC] leading-relaxed font-normal">
            <p className="text-[#F4F5EC] font-medium">{t('census.label')}</p>
          </div>
        </div>
      </section>

      {/* 4-Step How It Works */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#B8F34A] bg-[#12372A] px-3 py-1 rounded-md border border-[#B8F34A]/30 mb-3">
            <span>Simple 4-Step Flow</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-bold text-[#F4F5EC] tracking-tight font-display">
            {t('workflow.title')}
          </h2>
          <p className="mt-2 text-sm sm:text-base text-[#A5B7AC] font-normal">
            {t('workflow.subtitle')}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {workflowSteps.map((s) => {
            const IconComponent = s.icon;
            return (
              <div
                key={s.step}
                className="expert-card expert-card-hover p-6 rounded-xl flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 rounded-lg bg-[#0C2A20] border border-[#B8F34A]/30 text-[#B8F34A] flex items-center justify-center">
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-mono font-bold text-[#B8F34A] bg-[#0C2A20] px-2.5 py-0.5 rounded border border-[#B8F34A]/25">
                      STEP {s.step}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-[#F4F5EC] mb-1.5 font-display">
                    {s.title}
                  </h3>
                  <p className="text-sm text-[#A5B7AC] leading-relaxed font-normal">
                    {s.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Six Core Design Principles */}
      <section id="principles" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#B8F34A] bg-[#12372A] px-3 py-1 rounded-md border border-[#B8F34A]/30 mb-3">
            <span>Scientific Agronomy Invariants</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-bold text-[#F4F5EC] tracking-tight font-display">
            {t('principles.title')}
          </h2>
          <p className="mt-2 text-sm sm:text-base text-[#A5B7AC] font-normal">
            {t('principles.subtitle')}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {principlesList.map((p) => {
            const IconComp = p.icon;
            return (
              <div
                key={p.num}
                className="expert-card expert-card-hover p-6 rounded-xl flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 rounded-lg bg-[#0C2A20] border border-[#B8F34A]/30 text-[#B8F34A] flex items-center justify-center">
                      <IconComp className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-mono font-medium text-[#A5B7AC] bg-[#0C2A20] px-2 py-0.5 rounded border border-[#B8E6C8]/15">
                      {p.num}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-[#F4F5EC] mb-1.5 leading-snug font-display">
                    {p.title}
                  </h3>
                  <p className="text-sm text-[#A5B7AC] leading-relaxed font-normal">
                    {p.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Honest Pilot Scope Section */}
      <section id="pilot" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#12372A] text-[#F4F5EC] rounded-2xl p-8 sm:p-10 border border-[#B8E6C8]/15">
          <div className="max-w-3xl">
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#B8F34A] bg-[#0C2A20] px-2.5 py-1 rounded border border-[#B8F34A]/30 uppercase tracking-wider mb-3.5">
              {t('pilotScope.badge')}
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#F4F5EC] mb-3 font-display">
              {t('pilotScope.title')}
            </h2>
            <p className="text-sm sm:text-base text-[#A5B7AC] leading-relaxed mb-6 font-normal">
              {t('pilotScope.desc')}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-5 border-t border-[#B8E6C8]/15">
              <div className="bg-[#0C2A20] p-4 rounded-xl border border-[#B8E6C8]/15">
                <div className="text-xs text-[#A5B7AC] font-semibold uppercase tracking-wider">Crop Focus</div>
                <div className="text-base font-bold text-[#B8F34A] mt-1 font-display">{t('pilotScope.cropTarget')}</div>
              </div>
              <div className="bg-[#0C2A20] p-4 rounded-xl border border-[#B8E6C8]/15">
                <div className="text-xs text-[#A5B7AC] font-semibold uppercase tracking-wider">Pilot Locality</div>
                <div className="text-base font-bold text-[#F4F5EC] mt-1 font-display">{t('pilotScope.locationTarget')}</div>
              </div>
              <div className="bg-[#0C2A20] p-4 rounded-xl border border-[#B8E6C8]/15">
                <div className="text-xs text-[#A5B7AC] font-semibold uppercase tracking-wider">Testing Horizon</div>
                <div className="text-base font-bold text-[#F4F5EC] mt-1 font-display">{t('pilotScope.durationTarget')}</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Safety & Non-Commercial Manifesto */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="expert-card p-6 sm:p-8 rounded-2xl bg-[#12372A] border-[#B8E6C8]/20">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-[#0C2A20] border border-[#B8F34A]/30 text-[#B8F34A] flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5 text-[#B8F34A]" />
            </div>
            <div className="space-y-2">
              <h3 className="text-base sm:text-lg font-bold text-[#F4F5EC] font-display">
                {t('principles.p6Title')} &amp; Neutral Guidance Manifesto
              </h3>
              <p className="text-sm text-[#A5B7AC] leading-relaxed font-normal">
                {t('principles.p5Desc')} {t('principles.p6Desc')}
              </p>
              <div className="text-xs font-medium text-[#B8F34A] pt-1.5 flex flex-wrap gap-x-4 gap-y-1">
                <span className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5" />
                  Zero input sales
                </span>
                <span className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5" />
                  No chemical brand promotion
                </span>
                <span className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5" />
                  Strictly cultural &amp; biological first steps
                </span>
                <span className="flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5" />
                  Extension officer verification
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Accordion */}
      <section id="faq" className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#A5B7AC] bg-[#12372A] px-3 py-1 rounded-md border border-[#B8E6C8]/15 mb-3">
            <span>Clarifications</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#F4F5EC] tracking-tight font-display">
            {t('faq.title')}
          </h2>
        </div>

        <div className="space-y-2.5">
          {[
            { q: t('faq.q1'), a: t('faq.a1') },
            { q: t('faq.q2'), a: t('faq.a2') },
            { q: t('faq.q3'), a: t('faq.a3') },
          ].map((item, index) => (
            <div
              key={index}
              className="expert-card rounded-xl overflow-hidden"
            >
              <button
                type="button"
                onClick={() => toggleFaq(index)}
                className="w-full touch-target-48 px-5 py-4 text-left flex items-center justify-between gap-4 font-semibold text-[#F4F5EC] hover:bg-[#164233] transition-colors cursor-pointer"
                aria-expanded={openFaq === index}
              >
                <span className="text-sm sm:text-base font-display">{item.q}</span>
                <ChevronDown
                  className={`w-4 h-4 text-[#A5B7AC] shrink-0 transition-transform duration-150 ${
                    openFaq === index ? 'rotate-180 text-[#B8F34A]' : ''
                  }`}
                />
              </button>
              {openFaq === index && (
                <div className="px-5 pb-4 pt-1 text-sm text-[#A5B7AC] leading-relaxed border-t border-[#B8E6C8]/15 font-normal bg-[#0C2A20]">
                  {item.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Contact Form */}
      <section id="contact" className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="expert-card p-6 sm:p-8 rounded-2xl">
          <div className="text-center mb-7">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#F4F5EC] font-display">
              {t('contact.title')}
            </h2>
            <p className="mt-1 text-sm text-[#A5B7AC]">
              {t('contact.subtitle')}
            </p>
          </div>

          {submitSuccess && (
            <div className="mb-5 p-3.5 rounded-lg bg-[#0C2A20] border border-[#B8F34A]/40 text-[#B8F34A] text-sm flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-[#B8F34A] shrink-0" />
              <span className="font-semibold">{t('contact.success')}</span>
            </div>
          )}

          <form onSubmit={handleContactSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-[#F4F5EC] uppercase tracking-wider mb-1.5">
                  {t('contact.name')} *
                </label>
                <input
                  type="text"
                  required
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  className="w-full touch-target-48 px-3.5 py-2.5 rounded-lg border border-[#B8E6C8]/20 text-sm focus:border-[#B8F34A] focus:ring-1 focus:ring-[#B8F34A] bg-[#0C2A20] text-[#F4F5EC] outline-none transition-colors"
                  placeholder="e.g. Biren Saikia"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#F4F5EC] uppercase tracking-wider mb-1.5">
                  {t('contact.email')}
                </label>
                <input
                  type="text"
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                  className="w-full touch-target-48 px-3.5 py-2.5 rounded-lg border border-[#B8E6C8]/20 text-sm focus:border-[#B8F34A] focus:ring-1 focus:ring-[#B8F34A] bg-[#0C2A20] text-[#F4F5EC] outline-none transition-colors"
                  placeholder="phone or email"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#F4F5EC] uppercase tracking-wider mb-1.5">
                {t('contact.subject')}
              </label>
              <input
                type="text"
                value={contactSubject}
                onChange={(e) => setContactSubject(e.target.value)}
                className="w-full touch-target-48 px-3.5 py-2.5 rounded-lg border border-[#B8E6C8]/20 text-sm focus:border-[#B8F34A] focus:ring-1 focus:ring-[#B8F34A] bg-[#0C2A20] text-[#F4F5EC] outline-none transition-colors"
                placeholder="e.g. Field observations in Nagaon"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#F4F5EC] uppercase tracking-wider mb-1.5">
                {t('contact.message')} *
              </label>
              <textarea
                required
                rows={4}
                value={contactMessage}
                onChange={(e) => setContactMessage(e.target.value)}
                className="w-full p-3.5 rounded-lg border border-[#B8E6C8]/20 text-sm focus:border-[#B8F34A] focus:ring-1 focus:ring-[#B8F34A] bg-[#0C2A20] text-[#F4F5EC] outline-none transition-colors"
                placeholder="Write your observation or inquiry..."
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full touch-target-48 px-6 py-3.5 bg-[#B8F34A] hover:bg-[#c9f863] text-[#071C16] font-bold rounded-lg shadow-[0_0_15px_rgba(184,243,74,0.3)] btn-tactile cursor-pointer flex items-center justify-center gap-2 text-sm sm:text-base transition-all disabled:opacity-50"
            >
              <Send className="w-4 h-4 text-[#071C16]" />
              <span>{isSubmitting ? t('contact.sending') : t('contact.submit')}</span>
            </button>
          </form>
        </div>
      </section>
    </div>
  );
};
