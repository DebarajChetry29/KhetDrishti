import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  ShieldCheck,
  ArrowLeft,
  UserCheck,
  AlertTriangle,
  Clock,
  Phone,
  CheckCircle2,
  Send,
  Filter,
  Eye,
  BookOpen,
  Search,
  LogIn,
  LogOut,
  Camera,
  Check,
  FileCheck,
  Tag,
  RefreshCw,
  UploadCloud,
  FileSpreadsheet,
  Download,
  Database,
  AlertCircle
} from 'lucide-react';
import { AppRoute } from '../hooks/useRoute';
import {
  seedPilotDataToFirestore,
  parseCsvText,
  validateImportFile,
  downloadCsvTemplate,
  ImportValidationResult,
  REQUIRED_SCHEMAS
} from '../services/dataImportService';
import { auth, signInAsExpert, logOut, db, handleFirestoreError, OperationType } from '../firebase/config';
import { onAuthStateChanged, User } from 'firebase/auth';
import {
  collection,
  query,
  where,
  getDocs,
  doc,
  updateDoc,
  setDoc,
  orderBy,
  onSnapshot
} from 'firebase/firestore';
import {
  PILOT_CAUSES,
  PILOT_QUESTIONS,
  PILOT_NEXT_STEPS,
  Cause,
  NextStep
} from '../data/knowledgeBase';
import { getAllLocalCases, updateLocalCaseStatus, FarmerCase } from '../db/indexedDB';

interface ExpertDashboardProps {
  onNavigate: (route: AppRoute) => void;
}

type ExpertTab = 'queue' | 'kb' | 'import';
type StatusFilter = 'all' | 'escalated' | 'resolved';

export const ExpertDashboard: React.FC<ExpertDashboardProps> = ({ onNavigate }) => {
  const { t, i18n } = useTranslation();
  const currentLang = (i18n.language as 'as' | 'hi' | 'en') || 'as';

  // Auth state
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [demoOfficerActive, setDemoOfficerActive] = useState(false);

  // Active view tab
  const [activeTab, setActiveTab] = useState<ExpertTab>('queue');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');

  // Case Queue state
  const [cases, setCases] = useState<FarmerCase[]>([]);
  const [selectedCase, setSelectedCase] = useState<FarmerCase | null>(null);
  const [replyText, setReplyText] = useState('');
  const [isSubmittingReply, setIsSubmittingReply] = useState(false);
  const [replyFeedback, setReplyFeedback] = useState<string | null>(null);
  const [expandedPhoto, setExpandedPhoto] = useState<string | null>(null);

  // Knowledge base state
  const [kbSteps, setKbSteps] = useState<NextStep[]>(PILOT_NEXT_STEPS);
  const [kbFeedback, setKbFeedback] = useState<string | null>(null);

  // Data Import & Seed state
  const [isSeedingFirestore, setIsSeedingFirestore] = useState(false);
  const [seedStatus, setSeedStatus] = useState<string | null>(null);
  const [importValidation, setImportValidation] = useState<ImportValidationResult | null>(null);
  const [importedFileName, setImportedFileName] = useState<string | null>(null);
  const [isCommittingImport, setIsCommittingImport] = useState(false);
  const [importSuccess, setImportSuccess] = useState<string | null>(null);

  // Monitor Firebase Auth state
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setIsAuthLoading(false);
    });
    return () => unsub();
  }, []);

  // Fetch Cases from Firestore & IndexedDB
  const fetchEscalatedCases = async () => {
    try {
      const caseList: FarmerCase[] = [];

      // 1. Fetch from Firestore if user is authenticated
      if (currentUser || demoOfficerActive) {
        try {
          const q = query(
            collection(db, 'cases'),
            where('isEscalated', '==', true)
          );
          const snap = await getDocs(q);
          snap.forEach((d) => {
            const data = d.data() as any;
            caseList.push({
              id: d.id,
              userId: data.userId || 'anonymous',
              farmerPhone: data.farmerPhone,
              crop: data.crop || 'wheat',
              photoBase64: data.photoBase64,
              photoSizeKb: data.photoSizeKb,
              answers: data.answers || {},
              result: data.result || {
                candidates: [],
                disclaimer: { en: '', as: '', hi: '' },
                isEscalated: true,
                escalationReason: 'none',
                escalationMessage: { en: '', as: '', hi: '' },
                notSureCount: 0,
                totalAnswered: 0,
              },
              status: data.status || 'sent',
              isEscalated: true,
              expertReply: data.expertReply,
              createdAt: data.createdAt || new Date().toISOString(),
              updatedAt: data.updatedAt || new Date().toISOString(),
              syncedToFirestore: true,
            });
          });
        } catch (cloudErr) {
          console.warn('Firestore case fetch deferred (rules/offline):', cloudErr);
        }
      }

      // 2. Also merge any local IndexedDB cases
      const localCases = await getAllLocalCases();
      for (const loc of localCases) {
        if (!caseList.some((c) => c.id === loc.id)) {
          caseList.push(loc);
        }
      }

      // Sort newest first
      caseList.sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
      setCases(caseList);

      if (caseList.length > 0 && !selectedCase) {
        setSelectedCase(caseList[0]);
      }
    } catch (e) {
      console.error('Error fetching cases for expert queue:', e);
    }
  };

  useEffect(() => {
    fetchEscalatedCases();
  }, [currentUser, demoOfficerActive]);

  // Google Login Handler
  const handleGoogleLogin = async () => {
    try {
      await signInAsExpert();
    } catch (err) {
      console.error('Expert Google Login error:', err);
    }
  };

  // Demo Officer Toggle for evaluation
  const handleToggleDemoOfficer = () => {
    setDemoOfficerActive(!demoOfficerActive);
  };

  // Send Advisory Reply
  const handleSendReply = async () => {
    if (!selectedCase || !replyText.trim()) return;

    setIsSubmittingReply(true);
    const expertName =
      currentUser?.displayName ||
      (demoOfficerActive ? 'Dr. B. Bora (Nagaon Extension Officer)' : 'Agriculture Expert');

    const expertAdvice = {
      expertId: currentUser?.uid || 'expert_demo_1',
      expertName,
      advice: replyText.trim(),
      repliedAt: new Date().toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    try {
      // 1. Update Firestore case document if available
      try {
        const caseDocRef = doc(db, 'cases', selectedCase.id);
        await updateDoc(caseDocRef, {
          status: 'expert_replied',
          expertReply: expertAdvice,
          updatedAt: new Date().toISOString(),
        });

        // Add to expertReplies collection
        const replyId = `reply_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
        await setDoc(doc(db, 'expertReplies', replyId), {
          id: replyId,
          caseId: selectedCase.id,
          expertId: currentUser?.uid || 'expert_demo_1',
          expertName,
          advice: replyText.trim(),
          createdAt: new Date().toISOString(),
        });
      } catch (cloudErr) {
        console.warn('Firestore reply write offline or demo mode:', cloudErr);
      }

      // 2. Update local IndexedDB so farmer can see it immediately
      await updateLocalCaseStatus(selectedCase.id, 'expert_replied', expertAdvice);

      setReplyFeedback('Advisory reply transmitted successfully to farmer.');
      setReplyText('');

      // Refresh case list
      await fetchEscalatedCases();
      setSelectedCase((prev) =>
        prev
          ? {
              ...prev,
              status: 'expert_replied',
              expertReply: expertAdvice,
            }
          : null
      );

      setTimeout(() => setReplyFeedback(null), 5000);
    } catch (err) {
      console.error('Failed to submit expert reply:', err);
    } finally {
      setIsSubmittingReply(false);
    }
  };

  // Mark Case Resolved
  const handleMarkResolved = async () => {
    if (!selectedCase) return;

    try {
      try {
        const caseDocRef = doc(db, 'cases', selectedCase.id);
        await updateDoc(caseDocRef, {
          status: 'resolved',
          updatedAt: new Date().toISOString(),
        });
      } catch (cloudErr) {
        console.warn('Firestore update resolved offline/demo:', cloudErr);
      }

      await updateLocalCaseStatus(selectedCase.id, 'expert_replied');
      await fetchEscalatedCases();
      setReplyFeedback('Case status updated to resolved.');
      setTimeout(() => setReplyFeedback(null), 4000);
    } catch (err) {
      console.error('Failed to mark resolved:', err);
    }
  };

  // Verify / Certify a Knowledge Base step
  const handleVerifyStep = (stepId: string) => {
    setKbSteps((prev) =>
      prev.map((s) =>
        s.id === stepId
          ? {
              ...s,
              isPlaceholder: false,
              reviewedBy:
                currentUser?.displayName || 'Dr. B. Bora (Nagaon Extension Officer)',
              reviewedOn: '2026-03-20',
            }
          : s
      )
    );
    setKbFeedback('Agronomic guideline certified and stamped for Nagaon wheat pilot.');
    setTimeout(() => setKbFeedback(null), 4000);
  };

  // Seed Knowledge Base to Firestore
  const handleSeedPilotKnowledgeBase = async () => {
    setIsSeedingFirestore(true);
    setSeedStatus(null);
    try {
      const res = await seedPilotDataToFirestore();
      if (res.success) {
        setSeedStatus(
          `Successfully seeded complete baseline knowledge: ${res.insertedCount} records loaded across causes, questions, rules, and steps.`
        );
      } else {
        setSeedStatus(`Database write deferred or failed: ${res.error}`);
      }
    } catch (err) {
      setSeedStatus('Database seeding error. Ensure active Firestore connection.');
    } finally {
      setIsSeedingFirestore(false);
      setTimeout(() => setSeedStatus(null), 7000);
    }
  };

  // Handle CSV/JSON file upload & validation
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportedFileName(file.name);
    setImportSuccess(null);
    try {
      const text = await file.text();
      const { headers, rows } = parseCsvText(text);
      const res = validateImportFile(headers, rows);
      setImportValidation(res);
    } catch (err) {
      console.error('File validation error:', err);
    }
  };

  // Commit imported rows to Firestore
  const handleCommitImport = async () => {
    if (!importValidation || !importValidation.isValid || !importValidation.parsedData) return;

    setIsCommittingImport(true);
    setImportSuccess(null);
    try {
      const collectionName = importValidation.detectedType;
      let count = 0;
      for (const row of importValidation.parsedData) {
        const docId = row.id || `custom_${Date.now()}_${count++}`;
        await setDoc(doc(db, collectionName, docId), {
          ...row,
          updatedAt: new Date().toISOString(),
          importedBy: currentUser?.displayName || 'Nagaon Extension Specialist',
        });
      }
      setImportSuccess(
        `Successfully committed ${importValidation.rowCount} valid records to collection: [${collectionName}].`
      );
      setImportValidation(null);
      setImportedFileName(null);
    } catch (err) {
      console.error('Commit import error:', err);
      setImportSuccess('Failed to write all records to Firestore. Check permissions.');
    } finally {
      setIsCommittingImport(false);
    }
  };

  // Filtered case queue
  const filteredCases = cases.filter((c) => {
    if (statusFilter === 'escalated') return c.status !== 'expert_replied';
    if (statusFilter === 'resolved') return c.status === 'expert_replied';
    return true;
  });

  const isAuthenticated = !!currentUser || demoOfficerActive;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-[#F4F5EC]">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#B8E6C8]/15">
        <div>
          <button
            type="button"
            onClick={() => onNavigate('/')}
            className="touch-target-48 flex items-center gap-2 text-sm font-semibold text-[#A5B7AC] hover:text-[#B8F34A] transition-colors cursor-pointer mb-1 group"
          >
            <ArrowLeft className="w-4 h-4 text-[#B8F34A] group-hover:-translate-x-1 transition-transform" />
            <span>{t('app.back')}</span>
          </button>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#B8F34A] bg-[#0C2A20] px-3 py-1 rounded border border-[#B8F34A]/30 font-mono mb-2">
            <span>Agronomic Officer Console</span>
            <span aria-hidden="true" className="text-[#A5B7AC]">·</span>
            <span className="text-[#B8E6C8]">Nagaon Pilot</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-bold text-[#F4F5EC] tracking-tight font-display">
            {t('expert.title')}
          </h1>
          <p className="text-xs sm:text-sm text-[#A5B7AC] mt-1">
            {t('expert.subtitle')} · Nagaon KVK Extension Portal
          </p>
        </div>

        {/* Auth status & Tab switchers */}
        <div className="flex flex-wrap items-center gap-3">
          {isAuthenticated ? (
            <div className="flex items-center gap-2 bg-[#0C2A20] border border-[#B8F34A]/30 px-3 py-1.5 rounded-lg text-xs text-[#F4F5EC]">
              <UserCheck className="w-4 h-4 text-[#B8F34A]" />
              <span className="font-bold text-[#B8F34A] truncate max-w-[150px]">
                {currentUser?.displayName || currentUser?.email || 'Dr. B. Bora (KVK)'}
              </span>
              <button
                type="button"
                onClick={() => {
                  logOut();
                  setDemoOfficerActive(false);
                }}
                className="text-[#A5B7AC] hover:text-[#F4F5EC] ml-1 cursor-pointer"
                title="Sign out"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleGoogleLogin}
                className="touch-target-48 px-3.5 py-2 bg-[#B8F34A] hover:bg-[#c9f863] text-[#071C16] text-xs font-bold rounded-lg shadow-[0_0_12px_rgba(184,243,74,0.3)] flex items-center gap-2 cursor-pointer btn-tactile transition-all"
              >
                <LogIn className="w-3.5 h-3.5 text-[#071C16]" />
                <span>{t('expert.googleLogin')}</span>
              </button>
              <button
                type="button"
                onClick={handleToggleDemoOfficer}
                className="touch-target-48 px-3 py-2 bg-[#12372A] hover:bg-[#164233] text-[#F4F5EC] border border-[#B8E6C8]/20 text-xs font-semibold rounded-lg cursor-pointer btn-tactile transition-colors"
              >
                Demo Officer Mode
              </button>
            </div>
          )}

          {/* Tab Navigation */}
          <div className="flex items-center gap-1 p-1 bg-[#0C2A20] rounded-xl border border-[#B8E6C8]/15">
            <button
              type="button"
              onClick={() => setActiveTab('queue')}
              className={`touch-target-48 px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'queue'
                  ? 'bg-[#B8F34A] text-[#071C16] shadow-[0_0_12px_rgba(184,243,74,0.3)]'
                  : 'text-[#A5B7AC] hover:text-[#F4F5EC]'
              }`}
            >
              <AlertTriangle className={`w-3.5 h-3.5 ${activeTab === 'queue' ? 'text-[#071C16]' : 'text-[#A5B7AC]'}`} />
              <span>{t('expert.queueTitle')}</span>
              {cases.length > 0 && (
                <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-bold ${
                  activeTab === 'queue' ? 'bg-[#071C16] text-[#B8F34A]' : 'bg-[#12372A] text-[#B8F34A]'
                }`}>
                  {cases.length}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('kb')}
              className={`touch-target-48 px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'kb'
                  ? 'bg-[#B8F34A] text-[#071C16] shadow-[0_0_12px_rgba(184,243,74,0.3)]'
                  : 'text-[#A5B7AC] hover:text-[#F4F5EC]'
              }`}
            >
              <BookOpen className={`w-3.5 h-3.5 ${activeTab === 'kb' ? 'text-[#071C16]' : 'text-[#A5B7AC]'}`} />
              <span>{t('expert.kbTitle')}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('import')}
              className={`touch-target-48 px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'import'
                  ? 'bg-[#B8F34A] text-[#071C16] shadow-[0_0_12px_rgba(184,243,74,0.3)]'
                  : 'text-[#A5B7AC] hover:text-[#F4F5EC]'
              }`}
            >
              <Database className={`w-3.5 h-3.5 ${activeTab === 'import' ? 'text-[#071C16]' : 'text-[#A5B7AC]'}`} />
              <span>Data Import &amp; Seed</span>
            </button>
          </div>
        </div>
      </div>

      {/* TAB 1: ESCALATED CASE REVIEW QUEUE */}
      {activeTab === 'queue' && (
        <div className="space-y-6">
          {/* Status Filters */}
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-1 p-1 bg-[#0C2A20] rounded-xl border border-[#B8E6C8]/15">
              <button
                type="button"
                onClick={() => setStatusFilter('all')}
                className={`touch-target-48 px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  statusFilter === 'all'
                    ? 'bg-[#12372A] text-[#B8F34A] border border-[#B8F34A]/30 shadow-xs'
                    : 'text-[#A5B7AC] hover:text-[#F4F5EC]'
                }`}
              >
                {t('expert.filterAll')}
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('escalated')}
                className={`touch-target-48 px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  statusFilter === 'escalated'
                    ? 'bg-[#12372A] text-[#EAB308] border border-[#EAB308]/30 shadow-xs'
                    : 'text-[#A5B7AC] hover:text-[#F4F5EC]'
                }`}
              >
                {t('expert.filterEscalated')}
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('resolved')}
                className={`touch-target-48 px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  statusFilter === 'resolved'
                    ? 'bg-[#12372A] text-[#B8F34A] border border-[#B8F34A]/30 shadow-xs'
                    : 'text-[#A5B7AC] hover:text-[#F4F5EC]'
                }`}
              >
                {t('expert.filterResolved')}
              </button>
            </div>

            <button
              type="button"
              onClick={fetchEscalatedCases}
              className="touch-target-48 text-xs font-semibold text-[#B8F34A] hover:text-[#c9f863] flex items-center gap-1.5 cursor-pointer px-3.5 py-1.5 rounded-lg border border-[#B8E6C8]/20 bg-[#12372A] hover:bg-[#164233] transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5 text-[#B8F34A]" />
              <span>Refresh Queue</span>
            </button>
          </div>

          {/* Master-Detail Split Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Queue Column */}
            <div className="lg:col-span-5 space-y-2.5">
              {filteredCases.length === 0 ? (
                <div className="expert-card p-8 text-center text-[#A5B7AC] text-sm rounded-2xl bg-[#12372A] border border-[#B8E6C8]/15">
                  No cases matching the current filter.
                </div>
              ) : (
                filteredCases.map((c) => {
                  const isSelected = selectedCase?.id === c.id;
                  const topCause = c.result.candidates[0]?.cause;

                  return (
                    <div
                      key={c.id}
                      onClick={() => setSelectedCase(c)}
                      className={`p-4 rounded-xl border transition-all cursor-pointer space-y-2.5 ${
                        isSelected
                          ? 'border-[#B8F34A] bg-[#0C2A20] ring-1 ring-[#B8F34A] shadow-[0_0_15px_rgba(184,243,74,0.15)]'
                          : 'expert-card expert-card-hover bg-[#12372A] border-[#B8E6C8]/15'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-3">
                          {c.photoBase64 ? (
                            <img
                              src={c.photoBase64}
                              alt="Crop leaf"
                              className="w-12 h-12 rounded-lg object-cover border border-[#B8E6C8]/20 shrink-0"
                            />
                          ) : (
                            <div className="w-12 h-12 rounded-lg bg-[#0C2A20] text-[#B8F34A] border border-[#B8F34A]/30 flex items-center justify-center shrink-0">
                              <Camera className="w-5 h-5 text-[#B8F34A]" />
                            </div>
                          )}
                          <div>
                            <h4 className="text-sm font-bold text-[#F4F5EC] font-display">
                              {topCause?.name || 'Wheat Abnormality'}
                            </h4>
                            <div className="text-xs text-[#A5B7AC] flex items-center gap-1.5 mt-0.5 font-mono">
                              <span className="font-bold uppercase text-[#B8F34A]">{c.crop}</span>
                              <span aria-hidden="true" className="text-[#B8E6C8]/30">·</span>
                              <span className="tabular-nums">
                                {new Date(c.createdAt).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Status Label */}
                        <div className="text-right">
                          {c.status === 'expert_replied' ? (
                            <span className="text-[11px] font-mono font-bold text-[#071C16] bg-[#B8F34A] px-2.5 py-0.5 rounded shadow-[0_0_8px_rgba(184,243,74,0.25)]">
                              Resolved
                            </span>
                          ) : (
                            <span className="text-[11px] font-mono font-bold text-[#EAB308] bg-[#0C2A20] px-2 py-0.5 rounded border border-[#EAB308]/30">
                              Needs Review
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Phone metadata */}
                      <div className="flex items-center justify-between text-xs text-[#A5B7AC] pt-2 border-t border-[#B8E6C8]/15">
                        <span className="flex items-center gap-1.5 font-medium">
                          <Phone className="w-3.5 h-3.5 text-[#B8F34A]" />
                          <span>{c.farmerPhone || 'Anonymous Farmer'}</span>
                        </span>
                        <span className="font-mono text-[10px] text-[#A5B7AC]/80">
                          ID: {c.id.slice(0, 10)}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Right Case Inspection Detail */}
            <div className="lg:col-span-7 expert-card p-6 sm:p-7 rounded-2xl space-y-5 bg-[#12372A] border border-[#B8E6C8]/15 shadow-xl">
              {selectedCase ? (
                <>
                  {/* Case Header */}
                  <div className="flex items-start justify-between pb-3.5 border-b border-[#B8E6C8]/15 gap-4">
                    <div>
                      <div className="text-xs font-mono font-bold text-[#B8F34A] mb-1">
                        CASE: {selectedCase.id}
                      </div>
                      <h3 className="text-xl sm:text-2xl font-bold text-[#F4F5EC] font-display">
                        {selectedCase.result.candidates[0]?.cause.name || 'Wheat Case'}
                      </h3>
                      <div className="text-xs text-[#A5B7AC] flex items-center gap-3 mt-1 font-mono">
                        <span className="tabular-nums">
                          Submitted: {new Date(selectedCase.createdAt).toLocaleString()}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="font-semibold text-[#F4F5EC]">
                          Phone: {selectedCase.farmerPhone || 'Not provided'}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleMarkResolved}
                      className="touch-target-48 px-3.5 py-1.5 rounded-lg border border-[#B8E6C8]/20 text-xs font-semibold text-[#B8F34A] bg-[#0C2A20] hover:bg-[#164233] flex items-center gap-1.5 cursor-pointer whitespace-nowrap shadow-xs transition-colors"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#B8F34A]" />
                      <span>{t('expert.markResolved')}</span>
                    </button>
                  </div>

                  {/* Photo & Rules Breakdown */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Uploaded Photo */}
                    <div>
                      <div className="text-xs font-semibold text-[#F4F5EC] uppercase tracking-wider mb-2 font-mono">
                        Uploaded Photo
                      </div>
                      {selectedCase.photoBase64 ? (
                        <div
                          onClick={() => setExpandedPhoto(selectedCase.photoBase64!)}
                          className="relative rounded-xl overflow-hidden border border-[#B8E6C8]/20 bg-[#0C2A20] cursor-pointer group h-44 flex items-center justify-center shadow-xs"
                        >
                          <img
                            src={selectedCase.photoBase64}
                            alt="Leaf symptom"
                            className="h-full w-full object-cover group-hover:scale-105 transition-transform"
                          />
                          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-xs font-bold gap-1.5">
                            <Eye className="w-4 h-4 text-[#B8F34A]" />
                            <span>Click to Zoom</span>
                          </div>
                        </div>
                      ) : (
                        <div className="h-44 rounded-xl border border-dashed border-[#B8E6C8]/15 bg-[#0C2A20] flex items-center justify-center text-xs text-[#A5B7AC]">
                          No photo provided
                        </div>
                      )}
                    </div>

                    {/* Rules Engine Analysis */}
                    <div className="space-y-2.5">
                      <div className="text-xs font-semibold text-[#F4F5EC] uppercase tracking-wider font-mono">
                        {t('expert.ruleResult')}
                      </div>
                      <div className="p-3.5 bg-[#0C2A20] rounded-xl border border-[#B8E6C8]/15 text-xs space-y-2">
                        {selectedCase.result.candidates.map((cand, idx) => (
                          <div key={idx} className="flex items-center justify-between">
                            <span className="font-semibold text-[#F4F5EC]">
                              {cand.cause.name}
                            </span>
                            <span className="font-mono text-[#B8F34A] font-bold tabular-nums">
                              Score: {cand.score} ({cand.confidenceLevel.toUpperCase()})
                            </span>
                          </div>
                        ))}
                        {selectedCase.result.isEscalated && (
                          <div className="pt-2 border-t border-[#B8E6C8]/15 text-[#EAB308] font-bold font-mono">
                            Escalation Reason: {selectedCase.result.escalationReason}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Questionnaire Answers Audit */}
                  <div className="space-y-2 pt-1">
                    <h4 className="text-xs font-semibold text-[#F4F5EC] uppercase tracking-wider font-mono">
                      Farmer Symptom Questionnaire Answers
                    </h4>
                    <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                      {PILOT_QUESTIONS.map((q) => {
                        const answer = selectedCase.answers[q.id];
                        let answerBadge = (
                          <span className="text-[11px] text-[#A5B7AC] italic font-mono">Unanswered</span>
                        );
                        if (answer === 'yes') {
                          answerBadge = (
                            <span className="text-[11px] font-mono font-bold text-[#071C16] bg-[#B8F34A] px-2 py-0.5 rounded shadow-[0_0_8px_rgba(184,243,74,0.3)]">
                              YES
                            </span>
                          );
                        } else if (answer === 'no') {
                          answerBadge = (
                            <span className="text-[11px] font-mono font-medium text-[#F4F5EC] bg-[#12372A] px-2 py-0.5 rounded border border-[#B8E6C8]/20">
                              NO
                            </span>
                          );
                        } else if (answer === 'not_sure') {
                          answerBadge = (
                            <span className="text-[11px] font-mono font-medium text-[#EAB308] bg-[#0C2A20] px-2 py-0.5 rounded border border-[#EAB308]/30">
                              NOT SURE
                            </span>
                          );
                        }

                        return (
                          <div
                            key={q.id}
                            className="p-2.5 rounded-lg bg-[#0C2A20] border border-[#B8E6C8]/15 flex items-center justify-between text-xs gap-3"
                          >
                            <span className="text-[#F4F5EC] font-medium truncate">
                              {q.text.en}
                            </span>
                            {answerBadge}
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Prior Reply if exists */}
                  {selectedCase.expertReply && (
                    <div className="p-3.5 bg-[#0C2A20] border border-[#B8F34A]/30 rounded-xl space-y-1 text-xs">
                      <div className="font-bold text-[#B8F34A] flex items-center justify-between font-mono">
                        <span>Current Guidance by {selectedCase.expertReply.expertName}</span>
                        <span>
                          {selectedCase.expertReply.repliedAt}
                        </span>
                      </div>
                      <p className="text-[#F4F5EC] leading-relaxed text-sm font-medium">
                        {selectedCase.expertReply.advice}
                      </p>
                    </div>
                  )}

                  {/* Reply Composer */}
                  <div className="space-y-3 pt-3 border-t border-[#B8E6C8]/15">
                    <label className="block text-xs font-semibold text-[#F4F5EC] uppercase tracking-wider font-mono">
                      {t('expert.expertReplyLabel')}
                    </label>
                    <textarea
                      rows={3}
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      placeholder={t('expert.expertReplyPlaceholder')}
                      className="w-full p-3 rounded-lg border border-[#B8E6C8]/20 text-sm focus:border-[#B8F34A] focus:ring-1 focus:ring-[#B8F34A] bg-[#0C2A20] text-[#F4F5EC] outline-none"
                    />

                    <div className="flex items-center justify-between pt-1">
                      <span className="text-xs text-[#A5B7AC]">
                        Guidance will sync directly to the farmer&apos;s phone.
                      </span>

                      <button
                        type="button"
                        onClick={handleSendReply}
                        disabled={isSubmittingReply || !replyText.trim()}
                        className="touch-target-48 px-6 py-2.5 bg-[#B8F34A] hover:bg-[#c9f863] disabled:opacity-50 text-[#071C16] font-bold rounded-lg shadow-[0_0_15px_rgba(184,243,74,0.3)] btn-tactile cursor-pointer flex items-center gap-2 text-xs transition-all"
                      >
                        <Send className="w-3.5 h-3.5 text-[#071C16]" />
                        <span>{isSubmittingReply ? 'Sending...' : t('expert.sendReply')}</span>
                      </button>
                    </div>

                    {replyFeedback && (
                      <div className="p-3 bg-[#0C2A20] text-[#B8F34A] text-xs sm:text-sm font-bold rounded-lg border border-[#B8F34A]/40 flex items-center gap-2">
                        <Check className="w-4 h-4 text-[#B8F34A] shrink-0" />
                        <span>{replyFeedback}</span>
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <div className="text-center py-12 text-[#A5B7AC] text-sm">
                  Select a case from the queue to inspect details and provide expert advice.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: KNOWLEDGE BASE REVIEW SCREEN */}
      {activeTab === 'kb' && (
        <div className="expert-card p-6 sm:p-7 rounded-2xl space-y-6 bg-[#12372A] border border-[#B8E6C8]/15 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#B8E6C8]/15">
            <div>
              <h2 className="text-xl sm:text-3xl font-bold text-[#F4F5EC] font-display">
                {t('expert.kbTitle')}
              </h2>
              <p className="text-xs sm:text-sm text-[#A5B7AC] mt-0.5">
                Vetted symptoms and verified cultural next steps for Nagaon Wheat Pilot.
              </p>
            </div>
            <span className="text-xs font-bold text-[#B8F34A] bg-[#0C2A20] px-3.5 py-1.5 rounded-lg border border-[#B8F34A]/30 font-mono">
              Assam Agricultural University &amp; KVK Standards
            </span>
          </div>

          {kbFeedback && (
            <div className="p-3 bg-[#0C2A20] text-[#B8F34A] text-xs font-bold rounded-lg border border-[#B8F34A]/40 flex items-center gap-2">
              <Check className="w-4 h-4 text-[#B8F34A] shrink-0" />
              <span>{kbFeedback}</span>
            </div>
          )}

          <div className="space-y-5">
            {PILOT_CAUSES.map((cause) => {
              const causeSteps = kbSteps.filter((s) => s.causeId === cause.id);

              return (
                <div
                  key={cause.id}
                  className="p-5 rounded-2xl border border-[#B8E6C8]/15 bg-[#0C2A20] space-y-3.5 shadow-md"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-base sm:text-lg font-bold text-[#F4F5EC] font-display">
                          {cause.name} ({cause.assameseName})
                        </h3>
                        <span className="text-xs text-[#A5B7AC] font-mono italic">
                          {cause.scientificName}
                        </span>
                      </div>
                      <p className="text-xs sm:text-sm text-[#A5B7AC] mt-1 font-normal">
                        {cause.description.en}
                      </p>
                    </div>

                    <span
                      className={`text-xs px-2.5 py-0.5 rounded font-mono font-bold uppercase tracking-wider ${
                        cause.riskLevel === 'high'
                          ? 'text-[#F87171] bg-[#0C2A20] border border-[#F87171]/40'
                          : cause.riskLevel === 'medium'
                          ? 'text-[#EAB308] bg-[#0C2A20] border border-[#EAB308]/40'
                          : 'text-[#B8F34A] bg-[#0C2A20] border border-[#B8F34A]/40'
                      }`}
                    >
                      {cause.riskLevel} Risk
                    </span>
                  </div>

                  {/* Vetted steps list */}
                  <div className="space-y-2 pt-2.5 border-t border-[#B8E6C8]/15">
                    <h4 className="text-xs font-bold text-[#B8F34A] uppercase tracking-wider font-mono">
                      Management Next Steps
                    </h4>
                    <div className="space-y-2">
                      {causeSteps.map((step) => (
                        <div
                          key={step.id}
                          className="p-3.5 bg-[#12372A] rounded-xl border border-[#B8E6C8]/15 text-xs sm:text-sm text-[#A5B7AC] leading-relaxed flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                        >
                          <div className="space-y-0.5">
                            <p className="font-semibold text-[#F4F5EC]">{step.text.en}</p>
                            <div className="text-[11px] text-[#A5B7AC] flex items-center gap-2 font-mono">
                              <span className="font-bold text-[#B8F34A]">
                                {t('expert.reviewedBy')}: {step.reviewedBy}
                              </span>
                              <span aria-hidden="true" className="text-[#B8E6C8]/30">·</span>
                              <span>{t('expert.reviewedOn')}: {step.reviewedOn}</span>
                            </div>
                          </div>

                          <div className="shrink-0 flex items-center gap-2">
                            {step.isPlaceholder ? (
                              <button
                                type="button"
                                onClick={() => handleVerifyStep(step.id)}
                                className="touch-target-48 px-4 py-2 bg-[#B8F34A] hover:bg-[#c9f863] text-[#071C16] font-bold rounded-lg text-xs cursor-pointer shadow-xs btn-tactile transition-all"
                              >
                                Certify Step
                              </button>
                            ) : (
                              <span className="text-xs font-bold text-[#B8F34A] bg-[#0C2A20] border border-[#B8F34A]/30 px-3 py-1 rounded-lg font-mono flex items-center gap-1.5">
                                <FileCheck className="w-3.5 h-3.5 text-[#B8F34A]" />
                                <span>{t('expert.verified')}</span>
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: DATA SEED & CSV IMPORT UTILITY */}
      {activeTab === 'import' && (
        <div className="space-y-6">
          {/* Section 1: Cloud Firestore Seeding */}
          <div className="expert-card p-6 sm:p-7 rounded-2xl space-y-4 bg-[#12372A] border border-[#B8E6C8]/15 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-[#0C2A20] text-[#B8F34A] border border-[#B8F34A]/30 flex items-center justify-center">
                    <Database className="w-5 h-5 text-[#B8F34A]" />
                  </div>
                  <h3 className="text-lg sm:text-xl font-bold text-[#F4F5EC] font-display">
                    Seed Pilot Knowledge Base to Cloud Firestore
                  </h3>
                </div>
                <p className="text-xs sm:text-sm text-[#A5B7AC] leading-relaxed">
                  Loads the complete vetted Nagaon Wheat pilot dataset into your Firestore database
                  (<code className="font-mono text-[#B8F34A] text-xs font-medium">crops</code>, <code className="font-mono text-[#B8F34A] text-xs font-medium">causes</code>, <code className="font-mono text-[#B8F34A] text-xs font-medium">questions</code>, <code className="font-mono text-[#B8F34A] text-xs font-medium">rules</code>, <code className="font-mono text-[#B8F34A] text-xs font-medium">nextSteps</code>).
                </p>
              </div>

              <button
                type="button"
                onClick={handleSeedPilotKnowledgeBase}
                disabled={isSeedingFirestore}
                className="touch-target-48 px-6 py-3 bg-[#B8F34A] hover:bg-[#c9f863] disabled:opacity-50 text-[#071C16] font-bold rounded-lg shadow-[0_0_15px_rgba(184,243,74,0.3)] btn-tactile cursor-pointer flex items-center gap-2 text-xs shrink-0 transition-all"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-[#071C16] ${isSeedingFirestore ? 'animate-spin' : ''}`} />
                <span>{isSeedingFirestore ? 'Seeding Database...' : 'Seed Pilot Data'}</span>
              </button>
            </div>

            {seedStatus && (
              <div className="p-3.5 bg-[#0C2A20] border border-[#B8F34A]/30 rounded-xl text-xs sm:text-sm text-[#B8F34A] flex items-center gap-2 shadow-xs">
                <CheckCircle2 className="w-4 h-4 text-[#B8F34A] shrink-0" />
                <span>{seedStatus}</span>
              </div>
            )}
          </div>

          {/* Section 2: CSV / JSON File Uploader with Strict Schema Validation */}
          <div className="expert-card p-6 sm:p-7 rounded-2xl space-y-5 bg-[#12372A] border border-[#B8E6C8]/15 shadow-xl">
            <div className="space-y-1">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#0C2A20] text-[#B8F34A] border border-[#B8F34A]/30 flex items-center justify-center">
                  <UploadCloud className="w-5 h-5 text-[#B8F34A]" />
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-[#F4F5EC] font-display">
                  Custom Dataset Import (.CSV / .JSON)
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-[#A5B7AC] leading-relaxed">
                Attach field research data files. The system checks column schemas before writing to Firestore.
              </p>
            </div>

            {/* Upload Area */}
            <label className="border-2 border-dashed border-[#B8E6C8]/20 hover:border-[#B8F34A]/50 rounded-2xl p-8 text-center cursor-pointer bg-[#0C2A20] hover:bg-[#164233]/40 transition-colors flex flex-col items-center justify-center space-y-2.5 block group">
              <input
                type="file"
                accept=".csv, .json"
                onChange={handleFileUpload}
                className="hidden"
              />
              <div className="w-14 h-14 rounded-2xl bg-[#12372A] text-[#B8F34A] border border-[#B8F34A]/30 flex items-center justify-center group-hover:scale-105 transition-transform">
                <FileSpreadsheet className="w-7 h-7 text-[#B8F34A]" />
              </div>
              <div>
                <p className="text-sm font-bold text-[#F4F5EC]">
                  {importedFileName ? `Selected: ${importedFileName}` : 'Select or drop CSV / JSON file'}
                </p>
                <p className="text-xs text-[#A5B7AC] mt-0.5">
                  Supports symptoms, causes, rules, and verified steps
                </p>
              </div>
            </label>

            {/* Validation Outcome Report */}
            {importValidation && (
              <div
                className={`p-4 rounded-xl border text-xs sm:text-sm space-y-3 ${
                  importValidation.isValid
                    ? 'bg-[#0C2A20] border-[#B8F34A]/40 text-[#B8F34A]'
                    : 'bg-[#0C2A20] border-[#F87171]/40 text-[#F87171]'
                }`}
              >
                <div className="flex items-center justify-between font-bold font-mono">
                  <div className="flex items-center gap-2">
                    {importValidation.isValid ? (
                       <CheckCircle2 className="w-4 h-4 text-[#B8F34A]" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-[#F87171]" />
                    )}
                    <span>
                      {importValidation.isValid
                        ? `Valid Format: Target Collection [${importValidation.detectedType.toUpperCase()}]`
                        : 'Schema Mismatch Detected'}
                    </span>
                  </div>
                  <span className="text-xs">
                    {importValidation.rowCount} Rows Found
                  </span>
                </div>

                {!importValidation.isValid ? (
                  <div className="space-y-1.5 text-xs text-[#F87171] bg-[#12372A] p-3.5 rounded-lg border border-[#F87171]/30">
                    <p className="font-bold">{importValidation.error}</p>
                    <div>
                      <span className="font-medium">Columns Found in File: </span>
                      <code className="font-mono text-[#A5B7AC]">
                        {importValidation.foundColumns.join(', ') || 'None'}
                      </code>
                    </div>
                    <div>
                      <span className="font-medium">
                        Required Columns for [{importValidation.detectedType.toUpperCase()}]:{' '}
                      </span>
                      <code className="font-mono text-[#F87171] font-bold">
                        {REQUIRED_SCHEMAS[importValidation.detectedType as keyof typeof REQUIRED_SCHEMAS]?.join(', ') || 'Unknown'}
                      </code>
                    </div>
                  </div>
                ) : (
                  <div className="pt-2 flex items-center justify-between">
                    <span className="text-xs text-[#B8F34A] font-semibold">
                      All required columns verified. Ready for cloud persistence.
                    </span>
                    <button
                      type="button"
                      onClick={handleCommitImport}
                      disabled={isCommittingImport}
                      className="touch-target-48 px-5 py-2 bg-[#B8F34A] hover:bg-[#c9f863] disabled:opacity-50 text-[#071C16] font-bold rounded-lg text-xs cursor-pointer flex items-center gap-1.5 shadow-[0_0_12px_rgba(184,243,74,0.3)] btn-tactile transition-all"
                    >
                      <Database className="w-3.5 h-3.5 text-[#071C16]" />
                      <span>{isCommittingImport ? 'Writing to Firestore...' : 'Commit to Firestore'}</span>
                    </button>
                  </div>
                )}
              </div>
            )}

            {importSuccess && (
              <div className="p-4 bg-[#0C2A20] border border-[#B8F34A]/40 rounded-xl text-xs sm:text-sm text-[#B8F34A] flex items-center gap-2.5 shadow-xs font-semibold">
                <Check className="w-4 h-4 text-[#B8F34A] shrink-0" />
                <span>{importSuccess}</span>
              </div>
            )}
          </div>

          {/* Section 3: Download Sample CSV Templates */}
          <div className="expert-card rounded-2xl p-6 sm:p-7 border border-[#B8E6C8]/15 bg-[#12372A] shadow-xl space-y-3.5">
            <h3 className="text-base sm:text-lg font-bold text-[#F4F5EC] font-display">
              Download Standard CSV Templates
            </h3>
            <p className="text-xs sm:text-sm text-[#A5B7AC] leading-relaxed">
              Use these pre-formatted templates to ensure headers match the required Firestore schema:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-1">
              <button
                type="button"
                onClick={() => downloadCsvTemplate('causes')}
                className="touch-target-48 p-3.5 rounded-xl border border-[#B8E6C8]/15 hover:border-[#B8F34A]/50 bg-[#0C2A20] hover:bg-[#164233] text-left transition-all cursor-pointer flex flex-col justify-between group"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-[#F4F5EC] group-hover:text-[#B8F34A] transition-colors">1. Causes / Diseases</span>
                  <Download className="w-3.5 h-3.5 text-[#B8F34A]" />
                </div>
                <span className="text-[11px] text-[#A5B7AC] font-mono">causes.csv</span>
              </button>

              <button
                type="button"
                onClick={() => downloadCsvTemplate('questions')}
                className="touch-target-48 p-3.5 rounded-xl border border-[#B8E6C8]/15 hover:border-[#B8F34A]/50 bg-[#0C2A20] hover:bg-[#164233] text-left transition-all cursor-pointer flex flex-col justify-between group"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-[#F4F5EC] group-hover:text-[#B8F34A] transition-colors">2. Symptoms / Questions</span>
                  <Download className="w-3.5 h-3.5 text-[#B8F34A]" />
                </div>
                <span className="text-[11px] text-[#A5B7AC] font-mono">questions.csv</span>
              </button>

              <button
                type="button"
                onClick={() => downloadCsvTemplate('rules')}
                className="touch-target-48 p-3.5 rounded-xl border border-[#B8E6C8]/15 hover:border-[#B8F34A]/50 bg-[#0C2A20] hover:bg-[#164233] text-left transition-all cursor-pointer flex flex-col justify-between group"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-[#F4F5EC] group-hover:text-[#B8F34A] transition-colors">3. Diagnostic Rules</span>
                  <Download className="w-3.5 h-3.5 text-[#B8F34A]" />
                </div>
                <span className="text-[11px] text-[#A5B7AC] font-mono">rules.csv</span>
              </button>

              <button
                type="button"
                onClick={() => downloadCsvTemplate('nextSteps')}
                className="touch-target-48 p-3.5 rounded-xl border border-[#B8E6C8]/15 hover:border-[#B8F34A]/50 bg-[#0C2A20] hover:bg-[#164233] text-left transition-all cursor-pointer flex flex-col justify-between group"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-[#F4F5EC] group-hover:text-[#B8F34A] transition-colors">4. Cultural Steps</span>
                  <Download className="w-3.5 h-3.5 text-[#B8F34A]" />
                </div>
                <span className="text-[11px] text-[#A5B7AC] font-mono">next_steps.csv</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Expanded Photo Modal */}
      {expandedPhoto && (
        <div
          onClick={() => setExpandedPhoto(null)}
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md p-4 flex items-center justify-center cursor-pointer"
        >
          <div className="max-w-3xl max-h-[90vh] bg-[#0C2A20] rounded-2xl overflow-hidden shadow-2xl relative border border-[#B8E6C8]/25 p-2">
            <img
              src={expandedPhoto}
              alt="High resolution crop inspection"
              className="max-h-[80vh] w-auto object-contain mx-auto rounded-xl"
            />
            <div className="p-3 bg-[#12372A] text-[#B8F34A] text-center text-xs font-mono border-t border-[#B8E6C8]/15 mt-2 rounded-lg">
              Click anywhere to close full inspection view
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
