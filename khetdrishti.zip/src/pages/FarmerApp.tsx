import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Sprout,
  ArrowLeft,
  Camera,
  Upload,
  CheckCircle2,
  XCircle,
  HelpCircle,
  AlertTriangle,
  Volume2,
  VolumeX,
  UserCheck,
  Smartphone,
  RotateCcw,
  Clock,
  FolderOpen,
  ChevronRight,
  RefreshCw,
  Sparkles
} from 'lucide-react';
import { ensureFarmerAuth } from '../firebase/config';
import { syncService } from '../services/syncService';
import { AppRoute } from '../hooks/useRoute';
import {
  PILOT_QUESTIONS,
  PILOT_NEXT_STEPS,
  Question,
  Cause,
  NextStep,
} from '../data/knowledgeBase';
import {
  evaluateCropDiagnostics,
  DiagnosticResult,
  UserAnswersMap,
  UserAnswerValue,
} from '../services/rulesEngine';
import { compressImageClientSide } from '../services/imageCompression';
import { classifyImage } from '../services/imageClassifierHook';
import { speechService } from '../services/speechService';
import {
  saveCaseLocally,
  getAllLocalCases,
  FarmerCase,
  CaseSyncStatus,
} from '../db/indexedDB';

interface FarmerAppProps {
  onNavigate: (route: AppRoute) => void;
}

type FarmerStep = 'crop' | 'photo' | 'questions' | 'results';
type AppTab = 'diagnose' | 'cases';

export const FarmerApp: React.FC<FarmerAppProps> = ({ onNavigate }) => {
  const { t, i18n } = useTranslation();
  const currentLang = (i18n.language as 'as' | 'hi' | 'en') || 'as';

  // Navigation tabs: Diagnose vs My Cases
  const [activeTab, setActiveTab] = useState<AppTab>('diagnose');

  // Workflow steps
  const [currentStep, setCurrentStep] = useState<FarmerStep>('crop');
  const [selectedCrop, setSelectedCrop] = useState<string>('wheat');

  // Photo state
  const [photoBase64, setPhotoBase64] = useState<string | null>(null);
  const [photoSizeKb, setPhotoSizeKb] = useState<number>(0);
  const [isCompressing, setIsCompressing] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Questionnaire state
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState<number>(0);
  const [answers, setAnswers] = useState<UserAnswersMap>({});

  // Diagnosis results & escalation
  const [diagnosticResult, setDiagnosticResult] = useState<DiagnosticResult | null>(null);
  const [farmerPhone, setFarmerPhone] = useState<string>('');
  const [currentCaseId, setCurrentCaseId] = useState<string | null>(null);
  const [caseSaveFeedback, setCaseSaveFeedback] = useState<string | null>(null);

  // Speech narration state
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  // My Cases state
  const [savedCases, setSavedCases] = useState<FarmerCase[]>([]);
  const [selectedCaseDetail, setSelectedCaseDetail] = useState<FarmerCase | null>(null);
  const [currentFarmerUid, setCurrentFarmerUid] = useState<string>('');
  const [isManualSyncing, setIsManualSyncing] = useState<boolean>(false);

  // Load existing local cases
  const loadCases = async () => {
    try {
      const list = await getAllLocalCases();
      setSavedCases(list);
      return list;
    } catch (e) {
      console.error('Failed to load local IndexedDB cases:', e);
      return [];
    }
  };

  useEffect(() => {
    let isMounted = true;

    // 1. Ensure anonymous authentication for farmer before attaching Firestore listeners
    ensureFarmerAuth()
      .then(async (user) => {
        if (!isMounted) return;
        setCurrentFarmerUid(user.uid);

        // 2. Load cases from IndexedDB and attach expert reply watchers
        const cases = await loadCases();
        if (!isMounted) return;

        cases?.forEach((c) => {
          if (c.isEscalated) {
            syncService.watchCaseReplies(c.id);
          }
        });

        // 3. Sync pending cases to cloud
        await syncService.syncPendingCases();
        if (isMounted) {
          await loadCases();
        }
      })
      .catch((e) => {
        console.warn('Farmer auth init deferred offline:', e);
        if (isMounted) {
          loadCases();
        }
      });

    // 4. Online event listener to auto-sync
    const handleOnline = () => {
      syncService.syncPendingCases().then(() => {
        if (isMounted) loadCases();
      });
    };
    window.addEventListener('online', handleOnline);

    return () => {
      isMounted = false;
      speechService.stop();
      syncService.cleanup();
      window.removeEventListener('online', handleOnline);
    };
  }, []);

  const handleSyncNow = async () => {
    setIsManualSyncing(true);
    try {
      await syncService.syncPendingCases();
      await loadCases();
    } finally {
      setIsManualSyncing(false);
    }
  };

  // Handle Photo selection
  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsCompressing(true);
    try {
      const compressed = await compressImageClientSide(file, 150, 1024);
      setPhotoBase64(compressed.base64);
      setPhotoSizeKb(compressed.sizeKb);
    } catch (err) {
      console.error('Image compression error:', err);
    } finally {
      setIsCompressing(false);
    }
  };

  // Answer a question
  const handleAnswer = (value: UserAnswerValue) => {
    const activeQuestion = PILOT_QUESTIONS[currentQuestionIdx];
    const updatedAnswers = { ...answers, [activeQuestion.id]: value };
    setAnswers(updatedAnswers);

    if (currentQuestionIdx < PILOT_QUESTIONS.length - 1) {
      setCurrentQuestionIdx((prev) => prev + 1);
    } else {
      // Completed all questions -> run rules engine
      runDiagnosis(updatedAnswers);
    }
  };

  // Run transparent rule-based diagnosis & save to IndexedDB
  const runDiagnosis = async (finalAnswers: UserAnswersMap) => {
    // 1. Call dormant classifier hook
    const imageDetections = photoBase64 ? await classifyImage(photoBase64) : [];

    // 2. Evaluate with rules engine
    const result = evaluateCropDiagnostics(selectedCrop, finalAnswers, imageDetections);
    setDiagnosticResult(result);
    setCurrentStep('results');

    // 3. Immediately save to IndexedDB phone storage (Offline-first Principle 3)
    const user = await ensureFarmerAuth().catch(() => null);
    const userId = user?.uid || currentFarmerUid || `farmer_${Date.now()}`;
    const newCaseId = `case_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newCase: FarmerCase = {
      id: newCaseId,
      userId,
      farmerPhone: farmerPhone || undefined,
      crop: selectedCrop,
      photoBase64: photoBase64 || undefined,
      photoSizeKb,
      answers: finalAnswers,
      result,
      status: 'saved_locally',
      isEscalated: result.isEscalated,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      syncedToFirestore: false,
    };

    await saveCaseLocally(newCase);
    setCurrentCaseId(newCaseId);
    setCaseSaveFeedback(t('app.saveOfflineSuccess'));
    await loadCases();

    // 4. Background sync if connectivity is present
    syncService.syncPendingCases().then(() => loadCases());
  };

  // Escalate to Expert
  const handleEscalateToExpert = async () => {
    if (!currentCaseId) return;
    try {
      const existing = await getAllLocalCases();
      const match = existing.find((c) => c.id === currentCaseId);
      if (match) {
        match.isEscalated = true;
        match.farmerPhone = farmerPhone || match.farmerPhone;
        match.status = 'syncing'; // Transitioning to send queue
        await saveCaseLocally(match);
        await loadCases();
        setCaseSaveFeedback(t('app.escalatedNotice'));

        // Push to Firestore and listen for reply
        syncService.syncPendingCases().then(() => {
          loadCases();
          syncService.watchCaseReplies(currentCaseId);
        });
      }
    } catch (e) {
      console.error('Failed to escalate case locally:', e);
    }
  };

  // Audio Read-Aloud for Low-Literacy Users
  const handleToggleSpeech = (textToRead: string) => {
    if (isSpeaking) {
      speechService.stop();
      setIsSpeaking(false);
    } else {
      const success = speechService.speak(
        textToRead,
        currentLang,
        () => setIsSpeaking(true),
        () => setIsSpeaking(false)
      );
      if (!success) {
        setIsSpeaking(false);
      }
    }
  };

  // Reset workflow for new diagnosis
  const handleResetWorkflow = () => {
    speechService.stop();
    setIsSpeaking(false);
    setSelectedCrop('wheat');
    setPhotoBase64(null);
    setPhotoSizeKb(0);
    setCurrentQuestionIdx(0);
    setAnswers({});
    setDiagnosticResult(null);
    setCurrentCaseId(null);
    setCaseSaveFeedback(null);
    setCurrentStep('crop');
    setActiveTab('diagnose');
  };

  // Status badge styling helper (Futuristic AgriTech tags)
  const renderStatusBadge = (status: CaseSyncStatus) => {
    switch (status) {
      case 'saved_locally':
        return (
          <span className="text-[#A5B7AC] font-mono text-xs px-2.5 py-0.5 rounded bg-[#0C2A20] border border-[#B8E6C8]/15">
            {t('app.statusSaved')}
          </span>
        );
      case 'syncing':
        return (
          <span className="text-[#EAB308] font-mono text-xs px-2.5 py-0.5 rounded bg-[#0C2A20] border border-[#EAB308]/30">
            {t('app.statusSyncing')}
          </span>
        );
      case 'sent':
        return (
          <span className="text-[#B8F34A] font-mono text-xs px-2.5 py-0.5 rounded bg-[#0C2A20] border border-[#B8F34A]/30">
            {t('app.statusSent')}
          </span>
        );
      case 'expert_replied':
        return (
          <span className="text-[#071C16] bg-[#B8F34A] font-mono font-bold text-xs px-2.5 py-0.5 rounded shadow-[0_0_10px_rgba(184,243,74,0.3)]">
            {t('app.statusReplied')}
          </span>
        );
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 sm:py-8 space-y-6 text-[#F4F5EC]">
      {/* Top Header Bar */}
      <div className="flex items-center justify-between gap-4 pb-3.5 border-b border-[#B8E6C8]/15">
        <button
          type="button"
          onClick={() => onNavigate('/')}
          className="touch-target-48 flex items-center gap-2 text-sm font-semibold text-[#A5B7AC] hover:text-[#B8F34A] transition-colors cursor-pointer group"
        >
          <ArrowLeft className="w-4 h-4 text-[#B8F34A] group-hover:-translate-x-1 transition-transform" />
          <span>{t('app.back')}</span>
        </button>

        {/* Tab Switcher: Diagnose vs My Cases */}
        <div className="flex items-center gap-1 p-1 bg-[#0C2A20] rounded-xl border border-[#B8E6C8]/15">
          <button
            type="button"
            onClick={() => {
              setActiveTab('diagnose');
              setSelectedCaseDetail(null);
            }}
            className={`touch-target-48 px-4 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'diagnose'
                ? 'bg-[#B8F34A] text-[#071C16] shadow-[0_0_12px_rgba(184,243,74,0.3)]'
                : 'text-[#A5B7AC] hover:text-[#F4F5EC]'
            }`}
          >
            <Sprout className={`w-3.5 h-3.5 ${activeTab === 'diagnose' ? 'text-[#071C16]' : 'text-[#A5B7AC]'}`} />
            <span>{t('app.title')}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('cases');
              loadCases();
            }}
            className={`touch-target-48 px-4 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'cases'
                ? 'bg-[#B8F34A] text-[#071C16] shadow-[0_0_12px_rgba(184,243,74,0.3)]'
                : 'text-[#A5B7AC] hover:text-[#F4F5EC]'
            }`}
          >
            <FolderOpen className={`w-3.5 h-3.5 ${activeTab === 'cases' ? 'text-[#071C16]' : 'text-[#A5B7AC]'}`} />
            <span>{t('app.myCases')}</span>
            {savedCases.length > 0 && (
              <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-bold ${
                activeTab === 'cases' ? 'bg-[#071C16] text-[#B8F34A]' : 'bg-[#12372A] text-[#B8F34A]'
              }`}>
                {savedCases.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* TAB 1: DIAGNOSE WORKFLOW */}
      {activeTab === 'diagnose' && (
        <div className="space-y-6">
          {/* STEP 1: SELECT CROP */}
          {currentStep === 'crop' && (
            <div className="expert-card p-6 sm:p-7 rounded-2xl space-y-6 bg-[#12372A] border border-[#B8E6C8]/15 shadow-xl">
              <div className="text-center space-y-1.5">
                <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#B8F34A] bg-[#0C2A20] px-3 py-1 rounded border border-[#B8F34A]/30 uppercase tracking-wider font-mono">
                  <span>Step 1 of 4</span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-bold text-[#F4F5EC] font-display">
                  {t('app.selectCrop')}
                </h2>
                <p className="text-sm text-[#A5B7AC] font-normal">
                  {t('workflow.step1Desc')}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                {/* Wheat (Active in Nagaon Pilot) */}
                <button
                  type="button"
                  onClick={() => setSelectedCrop('wheat')}
                  className={`touch-target-48 p-4 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between group ${
                    selectedCrop === 'wheat'
                      ? 'border-[#B8F34A] bg-[#0C2A20] ring-1 ring-[#B8F34A] shadow-[0_0_15px_rgba(184,243,74,0.15)]'
                      : 'border-[#B8E6C8]/15 hover:border-[#B8E6C8]/30 bg-[#0C2A20]/50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-lg bg-[#12372A] text-[#B8F34A] border border-[#B8F34A]/30 flex items-center justify-center font-bold">
                      <Sprout className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-bold text-[#B8F34A] bg-[#12372A] px-2 py-0.5 rounded border border-[#B8F34A]/30">
                      {t('app.cropWheatDesc')}
                    </span>
                  </div>
                  <div>
                    <div className="text-base font-bold text-[#F4F5EC] font-display">
                      {t('app.cropWheat')}
                    </div>
                    <div className="text-xs text-[#A5B7AC] font-mono italic">Triticum aestivum</div>
                  </div>
                </button>

                {/* Rice (Disabled - Coming later) */}
                <div className="p-4 rounded-xl border border-dashed border-[#B8E6C8]/10 bg-[#0C2A20]/30 opacity-40 flex flex-col justify-between select-none">
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-lg bg-[#0C2A20] text-[#A5B7AC] flex items-center justify-center">
                      <Sprout className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] text-[#A5B7AC] font-medium bg-[#0C2A20] px-2 py-0.5 rounded">
                      {t('app.comingSoon')}
                    </span>
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-[#A5B7AC]">
                      {t('app.cropRice')}
                    </div>
                    <div className="text-xs text-[#A5B7AC] font-mono">Oryza sativa</div>
                  </div>
                </div>

                {/* Mustard (Disabled - Coming later) */}
                <div className="p-4 rounded-xl border border-dashed border-[#B8E6C8]/10 bg-[#0C2A20]/30 opacity-40 flex flex-col justify-between select-none">
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-lg bg-[#0C2A20] text-[#A5B7AC] flex items-center justify-center">
                      <Sprout className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] text-[#A5B7AC] font-medium bg-[#0C2A20] px-2 py-0.5 rounded">
                      {t('app.comingSoon')}
                    </span>
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-[#A5B7AC]">
                      {t('app.cropMustard')}
                    </div>
                    <div className="text-xs text-[#A5B7AC] font-mono">Brassica juncea</div>
                  </div>
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => setCurrentStep('photo')}
                  className="touch-target-48 w-full sm:w-auto px-7 py-3 bg-[#B8F34A] hover:bg-[#c9f863] text-[#071C16] font-bold rounded-lg shadow-[0_0_15px_rgba(184,243,74,0.25)] btn-tactile cursor-pointer flex items-center justify-center gap-2 text-sm sm:text-base transition-all"
                >
                  <span>{t('app.next')}</span>
                  <ChevronRight className="w-4 h-4 text-[#071C16]" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: ADD PHOTO */}
          {currentStep === 'photo' && (
            <div className="expert-card p-6 sm:p-7 rounded-2xl space-y-6 bg-[#12372A] border border-[#B8E6C8]/15 shadow-xl">
              <div className="flex items-center justify-between">
                <div>
                  <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#B8F34A] bg-[#0C2A20] px-2.5 py-0.5 rounded border border-[#B8F34A]/30 uppercase tracking-wider font-mono mb-1.5">
                    <span>Step 2 of 4</span>
                  </div>
                  <h2 className="text-2xl font-bold text-[#F4F5EC] font-display">
                    {t('app.takePhoto')}
                  </h2>
                  <p className="text-xs sm:text-sm text-[#A5B7AC] mt-0.5">
                    {t('app.photoHelp')}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setCurrentStep('crop')}
                  className="text-xs font-medium text-[#A5B7AC] hover:text-[#F4F5EC] touch-target-48 px-3 py-1.5 bg-[#0C2A20] rounded-lg border border-[#B8E6C8]/15 cursor-pointer"
                >
                  {t('app.back')}
                </button>
              </div>

              {/* Hidden file input */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handlePhotoSelect}
                className="hidden"
              />

              {/* Upload trigger or Image Preview */}
              {!photoBase64 ? (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-[#B8E6C8]/20 hover:border-[#B8F34A]/50 bg-[#0C2A20] hover:bg-[#164233]/40 p-8 sm:p-10 rounded-2xl text-center cursor-pointer transition-colors space-y-3 group"
                >
                  <div className="w-14 h-14 rounded-2xl bg-[#12372A] border border-[#B8F34A]/30 text-[#B8F34A] flex items-center justify-center mx-auto group-hover:scale-105 transition-transform">
                    <Camera className="w-7 h-7 text-[#B8F34A]" />
                  </div>
                  <div>
                    <p className="text-base font-bold text-[#F4F5EC] font-display">
                      {isCompressing ? t('common.loading') : t('app.takePhoto')}
                    </p>
                    <p className="text-xs text-[#A5B7AC] mt-1">
                      {t('hero.offlineNotice')} · Automatic field compression (&lt; 200 KB)
                    </p>
                  </div>
                  <div className="flex items-center justify-center gap-3 pt-2">
                    <span className="touch-target-48 px-4 py-2 bg-[#12372A] border border-[#B8E6C8]/20 rounded-lg text-xs font-semibold text-[#F4F5EC] flex items-center gap-2 group-hover:border-[#B8F34A]/50">
                      <Camera className="w-3.5 h-3.5 text-[#B8F34A]" />
                      <span>{t('app.uploadCamera')}</span>
                    </span>
                    <span className="touch-target-48 px-4 py-2 bg-[#12372A] border border-[#B8E6C8]/20 rounded-lg text-xs font-semibold text-[#F4F5EC] flex items-center gap-2 group-hover:border-[#B8F34A]/50">
                      <Upload className="w-3.5 h-3.5 text-[#B8F34A]" />
                      <span>{t('app.uploadGallery')}</span>
                    </span>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="relative rounded-2xl overflow-hidden border border-[#B8E6C8]/20 bg-[#0C2A20] max-h-80 flex items-center justify-center p-2">
                    <img
                      src={photoBase64}
                      alt="Crop symptom preview"
                      className="max-h-72 w-full object-contain rounded-xl"
                    />
                  </div>
                  <div className="flex items-center justify-between text-xs text-[#A5B7AC] pt-1">
                    <span className="font-semibold text-[#B8F34A] flex items-center gap-1.5 bg-[#0C2A20] px-3 py-1 rounded-lg border border-[#B8F34A]/30">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#B8F34A]" />
                      <span>{t('app.photoSelected')} ({photoSizeKb} KB compressed)</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setPhotoBase64(null);
                        setPhotoSizeKb(0);
                      }}
                      className="touch-target-48 font-medium text-[#B8F34A] hover:text-[#c9f863] flex items-center gap-1.5 cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>{t('app.retake')}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Navigation */}
              <div className="pt-3 flex items-center justify-between gap-4 border-t border-[#B8E6C8]/15">
                <button
                  type="button"
                  onClick={() => setCurrentStep('questions')}
                  className="text-xs font-medium text-[#A5B7AC] hover:text-[#B8F34A] cursor-pointer touch-target-48"
                >
                  Skip photo for now &rarr;
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentStep('questions')}
                  className="touch-target-48 px-7 py-3 bg-[#B8F34A] hover:bg-[#c9f863] text-[#071C16] font-bold rounded-lg shadow-[0_0_15px_rgba(184,243,74,0.25)] btn-tactile cursor-pointer flex items-center gap-2 text-sm sm:text-base transition-all"
                >
                  <span>{t('app.next')}</span>
                  <ChevronRight className="w-4 h-4 text-[#071C16]" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: 4-8 GUIDED QUESTIONS */}
          {currentStep === 'questions' && (
            <div className="expert-card p-6 sm:p-7 rounded-2xl space-y-6 bg-[#12372A] border border-[#B8E6C8]/15 shadow-xl">
              {/* Question Progress Header */}
              <div className="flex items-center justify-between border-b border-[#B8E6C8]/15 pb-4">
                <div className="flex items-center gap-1.5 text-xs font-bold text-[#B8F34A] bg-[#0C2A20] px-3 py-1 rounded border border-[#B8F34A]/30 font-mono">
                  <HelpCircle className="w-3.5 h-3.5 text-[#B8F34A]" />
                  <span>
                    {t('app.questionCount', {
                      current: currentQuestionIdx + 1,
                      total: PILOT_QUESTIONS.length,
                    })}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  {PILOT_QUESTIONS.map((_, idx) => (
                    <div
                      key={idx}
                      className={`h-1.5 rounded-full transition-all ${
                        idx === currentQuestionIdx
                          ? 'w-6 bg-[#B8F34A]'
                          : idx < currentQuestionIdx
                          ? 'w-2 bg-[#B8E6C8]'
                          : 'w-1.5 bg-[#0C2A20]'
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* Question Display */}
              <div className="space-y-3 py-1">
                <h2 className="text-xl sm:text-2xl font-bold text-[#F4F5EC] leading-snug font-display">
                  {PILOT_QUESTIONS[currentQuestionIdx].text[currentLang] ||
                    PILOT_QUESTIONS[currentQuestionIdx].text.en}
                </h2>

                {PILOT_QUESTIONS[currentQuestionIdx].helpText && (
                  <div className="p-3.5 bg-[#0C2A20] rounded-xl border border-[#B8E6C8]/15 text-xs sm:text-sm text-[#B8E6C8] leading-relaxed flex items-start gap-2.5">
                    <span className="text-base leading-none">💡</span>
                    <span>
                      {PILOT_QUESTIONS[currentQuestionIdx].helpText?.[currentLang] ||
                        PILOT_QUESTIONS[currentQuestionIdx].helpText?.en}
                    </span>
                  </div>
                )}
              </div>

              {/* High-Contrast Accessible Buttons (Yes / No / Not Sure) */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                {/* YES BUTTON */}
                <button
                  type="button"
                  onClick={() => handleAnswer('yes')}
                  className="touch-target-48 p-4 rounded-xl bg-[#B8F34A] hover:bg-[#c9f863] text-[#071C16] font-extrabold transition-all active:scale-[0.985] cursor-pointer flex items-center justify-center gap-2.5 text-base shadow-[0_0_15px_rgba(184,243,74,0.3)] btn-tactile"
                >
                  <CheckCircle2 className="w-5 h-5 text-[#071C16]" />
                  <span>{t('app.yes')}</span>
                </button>

                {/* NO BUTTON */}
                <button
                  type="button"
                  onClick={() => handleAnswer('no')}
                  className="touch-target-48 p-4 rounded-xl bg-[#12372A] hover:bg-[#164233] border border-[#B8E6C8]/25 hover:border-[#B8F34A]/40 text-[#F4F5EC] font-bold transition-all active:scale-[0.985] cursor-pointer flex items-center justify-center gap-2.5 text-base shadow-xs btn-tactile"
                >
                  <XCircle className="w-5 h-5 text-[#A5B7AC]" />
                  <span>{t('app.no')}</span>
                </button>

                {/* NOT SURE BUTTON */}
                <button
                  type="button"
                  onClick={() => handleAnswer('not_sure')}
                  className="touch-target-48 p-4 rounded-xl bg-[#0C2A20] hover:bg-[#12372A] border border-[#B8E6C8]/15 hover:border-[#B8E6C8]/30 text-[#A5B7AC] hover:text-[#F4F5EC] font-medium transition-all active:scale-[0.985] cursor-pointer flex items-center justify-center gap-2.5 text-base shadow-xs btn-tactile"
                >
                  <HelpCircle className="w-5 h-5 text-[#A5B7AC]" />
                  <span>{t('app.notSure')}</span>
                </button>
              </div>

              {/* Previous button */}
              {currentQuestionIdx > 0 && (
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => setCurrentQuestionIdx((p) => Math.max(0, p - 1))}
                    className="text-xs font-semibold text-[#A5B7AC] hover:text-[#B8F34A] cursor-pointer touch-target-48"
                  >
                    &larr; Previous question
                  </button>
                </div>
              )}
            </div>
          )}

          {/* STEP 4: RESULTS SCREEN */}
          {currentStep === 'results' && diagnosticResult && (
            <div className="space-y-6">
              {/* Mandatory Core Principle 1 Banner */}
              <div className="p-4 sm:p-5 bg-[#12372A] border border-[#EAB308]/40 rounded-2xl flex items-start gap-3 shadow-lg">
                <AlertTriangle className="w-5 h-5 text-[#EAB308] shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <div className="text-sm font-bold text-[#F4F5EC] font-display">
                    {diagnosticResult.disclaimer[currentLang] || diagnosticResult.disclaimer.en}
                  </div>
                  <div className="text-xs text-[#A5B7AC] leading-relaxed font-normal">
                    {t('disclaimer.safety')}
                  </div>
                </div>
              </div>

              {/* Human-in-the-Loop Escalation Notice if flagged */}
              {diagnosticResult.isEscalated && (
                <div className="p-5 bg-[#0C2A20] text-[#F4F5EC] rounded-2xl border border-[#B8E6C8]/20 space-y-3">
                  <div className="flex items-center gap-2 text-[#B8F34A] text-xs font-bold uppercase tracking-wider font-mono">
                    <UserCheck className="w-4 h-4 text-[#B8F34A]" />
                    <span>{t('principles.p2Title')} · Human In The Loop</span>
                  </div>
                  <p className="text-sm text-[#A5B7AC] leading-relaxed font-normal">
                    {diagnosticResult.escalationMessage[currentLang] ||
                      diagnosticResult.escalationMessage.en}
                  </p>
                  <div className="flex items-center gap-2 text-xs text-[#B8E6C8]">
                    <Smartphone className="w-4 h-4 text-[#B8F34A]" />
                    <span>Nagaon KVK agriculture extension queue ready.</span>
                  </div>
                </div>
              )}

              {/* 1-3 Possible Causes Card */}
              <div className="expert-card p-6 sm:p-7 rounded-2xl space-y-5 bg-[#12372A] border border-[#B8E6C8]/15 shadow-xl">
                <div className="flex items-center justify-between pb-3.5 border-b border-[#B8E6C8]/15">
                  <div>
                    <h2 className="text-2xl font-bold text-[#F4F5EC] font-display">
                      {t('app.resultsTitle')}
                    </h2>
                    <p className="text-xs text-[#A5B7AC] mt-0.5">
                      {t('app.resultsSubtitle')}
                    </p>
                  </div>
                  {currentCaseId && (
                    <span className="text-xs font-mono font-bold text-[#B8F34A] bg-[#0C2A20] px-2.5 py-1 rounded border border-[#B8F34A]/30">
                      ID: {currentCaseId.slice(0, 8)}
                    </span>
                  )}
                </div>

                {diagnosticResult.candidates.length === 0 ? (
                  <div className="text-center py-8 space-y-2">
                    <p className="text-base font-bold text-[#F4F5EC]">
                      No strong match from symptom rules.
                    </p>
                    <p className="text-xs text-[#A5B7AC] max-w-sm mx-auto">
                      Please escalate below with your photo so our agriculture expert can personally review.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {diagnosticResult.candidates.map((cand, idx) => {
                      const cause = cand.cause;
                      const causeSteps = PILOT_NEXT_STEPS.filter(
                        (s) => s.causeId === cause.id
                      );

                      // Confidence Badge
                      let confidenceText = t('app.confidenceLow');
                      let confidenceClass = 'text-[#A5B7AC] bg-[#0C2A20] border border-[#B8E6C8]/15';
                      if (cand.confidenceLevel === 'high') {
                        confidenceText = t('app.confidenceHigh');
                        confidenceClass = 'text-[#071C16] bg-[#B8F34A] font-bold shadow-[0_0_8px_rgba(184,243,74,0.3)]';
                      } else if (cand.confidenceLevel === 'medium') {
                        confidenceText = t('app.confidenceMedium');
                        confidenceClass = 'text-[#071C16] bg-[#EAB308] font-bold';
                      }

                      // Compile speech readout text
                      const speechReadout = `${cause.assameseName}. ${
                        cause.description[currentLang] || cause.description.en
                      }. ${causeSteps
                        .map((s) => s.text[currentLang] || s.text.en)
                        .join('. ')}`;

                      return (
                        <div
                          key={cause.id}
                          className="p-5 rounded-2xl border border-[#B8E6C8]/15 bg-[#0C2A20] space-y-3.5 hover:border-[#B8F34A]/40 transition-colors"
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div>
                              <div className="text-xs font-mono font-bold text-[#B8F34A] mb-1">
                                POSSIBILITY 0{idx + 1}
                              </div>
                              <h3 className="text-lg sm:text-xl font-bold text-[#F4F5EC] font-display">
                                {currentLang === 'as'
                                  ? cause.assameseName
                                  : currentLang === 'hi'
                                  ? cause.hindiName
                                  : cause.name}
                              </h3>
                              <p className="text-xs text-[#A5B7AC] italic font-serif">
                                {cause.scientificName}
                              </p>
                            </div>

                            {/* Confidence Indicator */}
                            <div className="text-right">
                              <span
                                className={`text-xs px-2.5 py-0.5 rounded font-mono ${confidenceClass}`}
                              >
                                {t('app.confidence')}: {confidenceText}
                              </span>
                            </div>
                          </div>

                          <p className="text-sm text-[#A5B7AC] leading-relaxed font-normal">
                            {cause.description[currentLang] || cause.description.en}
                          </p>

                          {/* Safe Next Steps */}
                          <div className="space-y-2.5 pt-3 border-t border-[#B8E6C8]/15">
                            <div className="flex items-center justify-between">
                              <h4 className="text-xs font-bold text-[#B8F34A] uppercase tracking-wider font-mono">
                                {t('app.safeNextSteps')}
                              </h4>

                              {/* Speech Synthesis Read-Aloud Button */}
                              <button
                                type="button"
                                onClick={() => handleToggleSpeech(speechReadout)}
                                className={`touch-target-48 px-3 py-1 text-xs font-semibold flex items-center gap-1.5 cursor-pointer rounded-lg transition-all ${
                                  isSpeaking
                                    ? 'bg-[#B8F34A] text-[#071C16] shadow-[0_0_12px_rgba(184,243,74,0.4)]'
                                    : 'bg-[#12372A] text-[#F4F5EC] hover:bg-[#164233] border border-[#B8E6C8]/20'
                                }`}
                              >
                                {isSpeaking ? (
                                  <>
                                    <VolumeX className="w-3.5 h-3.5 text-[#071C16]" />
                                    <span>{t('app.stopReading')}</span>
                                  </>
                                ) : (
                                  <>
                                    <Volume2 className="w-3.5 h-3.5 text-[#B8F34A]" />
                                    <span>{t('app.readAloud')}</span>
                                  </>
                                )}
                              </button>
                            </div>

                            <div className="space-y-2">
                              {causeSteps.map((step) => (
                                <div
                                  key={step.id}
                                  className="p-3.5 bg-[#12372A] rounded-xl border border-[#B8E6C8]/15 text-xs sm:text-sm text-[#A5B7AC] leading-relaxed space-y-1.5"
                                >
                                  <p className="font-semibold text-[#F4F5EC]">{step.text[currentLang] || step.text.en}</p>
                                  <div className="text-[11px] text-[#A5B7AC] flex flex-wrap items-center gap-2 pt-1 border-t border-[#B8E6C8]/10 font-mono">
                                    <span className="font-bold text-[#B8F34A]">✓ {step.reviewedBy}</span>
                                    <span>·</span>
                                    <span>{step.reviewedOn}</span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Farmer Phone & Escalation Action */}
                <div className="pt-3 border-t border-[#B8E6C8]/15 space-y-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-[#F4F5EC] uppercase tracking-wider mb-1.5 font-mono">
                      {t('app.phoneLabel')}
                    </label>
                    <input
                      type="tel"
                      value={farmerPhone}
                      onChange={(e) => setFarmerPhone(e.target.value)}
                      placeholder={t('app.phonePlaceholder')}
                      className="w-full touch-target-48 px-3.5 py-2.5 rounded-lg border border-[#B8E6C8]/20 text-sm focus:border-[#B8F34A] focus:ring-1 focus:ring-[#B8F34A] bg-[#0C2A20] text-[#F4F5EC] outline-none"
                    />
                  </div>

                  <div className="flex flex-col sm:flex-row items-center gap-3">
                    <button
                      type="button"
                      onClick={handleEscalateToExpert}
                      className="touch-target-48 w-full sm:flex-1 px-5 py-3.5 bg-[#B8F34A] hover:bg-[#c9f863] text-[#071C16] font-extrabold rounded-lg shadow-[0_0_15px_rgba(184,243,74,0.3)] btn-tactile cursor-pointer flex items-center justify-center gap-2 text-sm sm:text-base transition-all"
                    >
                      <UserCheck className="w-4 h-4 text-[#071C16]" />
                      <span>{t('app.askExpert')}</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleResetWorkflow}
                      className="touch-target-48 w-full sm:w-auto px-4 py-3.5 bg-[#0C2A20] hover:bg-[#12372A] text-[#F4F5EC] font-semibold rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 text-xs border border-[#B8E6C8]/20"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-[#B8F34A]" />
                      <span>New Diagnosis</span>
                    </button>
                  </div>

                  {caseSaveFeedback && (
                    <div className="p-3 bg-[#0C2A20] text-[#B8F34A] text-xs sm:text-sm font-semibold rounded-lg border border-[#B8F34A]/40 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#B8F34A] shrink-0" />
                      <span>{caseSaveFeedback}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: MY CASES (INDEXEDDB LIST) */}
      {activeTab === 'cases' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between pb-3.5 border-b border-[#B8E6C8]/15">
            <div>
              <h2 className="text-2xl font-bold text-[#F4F5EC] font-display">
                {t('app.myCases')}
              </h2>
              <p className="text-xs text-[#A5B7AC]">
                {t('hero.offlineNotice')}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleSyncNow}
                disabled={isManualSyncing}
                className="touch-target-48 px-3 py-1.5 bg-[#12372A] hover:bg-[#164233] text-[#F4F5EC] text-xs font-semibold rounded-lg cursor-pointer flex items-center gap-1.5 border border-[#B8E6C8]/20 shadow-xs disabled:opacity-50 transition-colors"
                title="Sync cases with Firestore"
              >
                <RefreshCw
                  className={`w-3.5 h-3.5 text-[#B8F34A] ${
                    isManualSyncing ? 'animate-spin' : ''
                  }`}
                />
                <span className="hidden sm:inline">Sync Cloud</span>
              </button>

              <button
                type="button"
                onClick={handleResetWorkflow}
                className="touch-target-48 px-3.5 py-1.5 bg-[#B8F34A] hover:bg-[#c9f863] text-[#071C16] text-xs font-bold rounded-lg shadow-[0_0_10px_rgba(184,243,74,0.3)] cursor-pointer flex items-center gap-1.5 transition-all"
              >
                <Sprout className="w-3.5 h-3.5 text-[#071C16]" />
                <span>New Check</span>
              </button>
            </div>
          </div>

          {savedCases.length === 0 ? (
            <div className="expert-card p-10 text-center space-y-2.5 rounded-2xl bg-[#12372A] border border-[#B8E6C8]/15">
              <div className="w-12 h-12 rounded-xl bg-[#0C2A20] text-[#B8F34A] flex items-center justify-center mx-auto border border-[#B8F34A]/30">
                <FolderOpen className="w-6 h-6 text-[#B8F34A]" />
              </div>
              <p className="text-base font-bold text-[#F4F5EC] font-display">
                {t('app.noCases')}
              </p>
              <p className="text-xs text-[#A5B7AC] max-w-xs mx-auto">
                Any crop observations you record will be preserved offline on this device.
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {savedCases.map((c) => (
                <div
                  key={c.id}
                  onClick={() =>
                    setSelectedCaseDetail(
                      selectedCaseDetail?.id === c.id ? null : c
                    )
                  }
                  className="expert-card expert-card-hover p-4 rounded-xl cursor-pointer space-y-3 bg-[#12372A] border border-[#B8E6C8]/15"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      {c.photoBase64 ? (
                        <img
                          src={c.photoBase64}
                          alt="Thumbnail"
                          className="w-12 h-12 rounded-lg object-cover border border-[#B8E6C8]/20"
                        />
                      ) : (
                        <div className="w-12 h-12 rounded-lg bg-[#0C2A20] text-[#B8F34A] border border-[#B8F34A]/30 flex items-center justify-center font-bold">
                          <Sprout className="w-5 h-5 text-[#B8F34A]" />
                        </div>
                      )}
                      <div>
                        <div className="text-sm font-bold text-[#F4F5EC] font-display">
                          {c.result.candidates[0]?.cause.name || 'Wheat Case'}
                        </div>
                        <div className="text-xs text-[#A5B7AC] flex items-center gap-1.5 mt-0.5 font-mono">
                          <Clock className="w-3 h-3 text-[#A5B7AC]" />
                          <span>{new Date(c.createdAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      {renderStatusBadge(c.status)}
                    </div>
                  </div>

                  {/* Expanded Detail Panel */}
                  {selectedCaseDetail?.id === c.id && (
                    <div className="pt-3 border-t border-[#B8E6C8]/15 space-y-2.5 text-xs">
                      {c.expertReply ? (
                        <div className="p-3.5 bg-[#0C2A20] border border-[#B8F34A]/30 rounded-lg space-y-1 text-[#F4F5EC]">
                          <div className="font-bold text-[#B8F34A] flex items-center gap-1.5">
                            <UserCheck className="w-4 h-4 text-[#B8F34A]" />
                            <span>
                              {t('app.expertAdvice')} ({c.expertReply.expertName})
                            </span>
                          </div>
                          <p className="text-[#F4F5EC] text-xs sm:text-sm leading-relaxed">
                            {c.expertReply.advice}
                          </p>
                          <span className="text-[10px] text-[#A5B7AC] font-mono block pt-1">
                            Replied: {c.expertReply.repliedAt}
                          </span>
                        </div>
                      ) : (
                        <div className="text-[#A5B7AC] bg-[#0C2A20] p-3 rounded-lg border border-[#B8E6C8]/15">
                          {c.isEscalated
                            ? 'Awaiting review from Nagaon agriculture officer.'
                            : 'Stored safely on phone.'}
                        </div>
                      )}

                      <div className="flex items-center justify-between text-[#A5B7AC] pt-1 font-mono text-[11px]">
                        <span>Case: {c.id.slice(0, 16)}</span>
                        <span className="uppercase text-[#B8F34A] font-semibold">{c.crop}</span>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
