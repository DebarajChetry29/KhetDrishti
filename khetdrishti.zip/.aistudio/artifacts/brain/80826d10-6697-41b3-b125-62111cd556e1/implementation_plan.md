# KhetDrishti: Mobile-First Offline PWA & Expert Advisory Platform

A mobile-first, offline-capable Progressive Web App and public project website designed for smallholder farmers in Nagaon, Assam, India. It empowers farmers experiencing wheat crop abnormalities to navigate from initial symptom discovery to safe, grounded, expert-reviewed agronomic next steps.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following core parameters and architectural decisions have been confirmed for the Nagaon, Assam pilot:

- **Authentication Strategy**: Frictionless Anonymous Sign-In plus phone number input for farmers; Google Sign-In with Firestore Role-Based Access Control (RBAC) for agriculture extension officers and experts.
- **Pilot Knowledge Base**: Pre-loaded with vetted wheat conditions for Assam (Yellow / Stripe Rust, Leaf / Brown Rust, Karnal Bunt, Loose Smut, Powdery Mildew, and Nitrogen/Zinc Micronutrient Deficiencies), complete with transparent "Reviewed By" & "Reviewed On" verification tags.
- **Low-Literacy & Accessibility**: Assamese as default language with seamless Hindi and English toggles; big $\ge 48\text{px}$ touch targets; high-contrast agricultural iconography; and Web Speech Synthesis API voice narration for all diagnostic outcomes and safety steps.
- **Non-Negotiable Core Principles**:
  1. *Possibilities, not verdicts*: 1–3 candidate causes with explicit confidence tiers (High / Medium / Low). Prominently marked: *"This is a possibility, not a final diagnosis."*
  2. *Human-in-the-loop*: Automatic escalation to agricultural officers whenever confidence is low, symptom answers conflict ("not sure"), or high-risk blights are suspected.
  3. *Offline-first*: Local IndexedDB persistence via Dexie.js; instant local case creation and queued background synchronization to Firestore with 4 explicit lifecycle states: `Saved on phone` $\rightarrow$ `Syncing` $\rightarrow$ `Sent` $\rightarrow$ `Expert replied`.
  4. *Neutral guidance & zero commercialization*: Strictly zero input sales, sponsored products, or brand names. All cultural and biological measures precede low-risk chemical interventions with mandatory safety warnings.

---

## 1. Overview & Core Concept

- **What It Does**: KhetDrishti provides a rapid, respectful 4-step mobile diagnostic flow for farmers in low-connectivity rural belts: capturing or selecting a crop leaf photo (compressed client-side to $\sim 150\text{KB}$), answering 4 to 8 visual Yes/No/Unsure questions, receiving grounded candidate causes with plain-language cultural next steps, and seamlessly escalating unresolved issues to certified experts.
- **Target Audience / Persona**: Smallholder wheat farmers in Nagaon District, Assam (where $\sim 86\%$ of operational holdings are under 2 hectares), who often face intermittent cellular coverage, varying literacy levels, and delayed access to Krishi Vigyan Kendra (KVK) extension officers.
- **Key Value**: Replaces guesswork and dangerous pesticide misuse with transparent, grounded, expert-verified advisory that functions reliably without an active internet connection.

---

## 2. User Experience & Visual Design

### Key User Flows

```
┌────────────────────────────────────────────────────────────────────────┐
│                          KHETDRISHTI APP ROUTES                        │
├───────────────────────┬────────────────────────┬───────────────────────┤
│    / (Public Web)     │    /app (Farmer PWA)   │  /expert (Dashboard)  │
├───────────────────────┼────────────────────────┼───────────────────────┤
│ • Hero & Mission      │ • Language Picker      │ • Officer Google Auth │
│ • Assam Census Proof  │ • Wheat Pilot Selector │ • Escalated Cases     │
│ • 4-Step How It Works │ • Client Compressed Pic│ • Answer & Photo View │
│ • 6 Core Principles   │ • 4-8 Icon Questions   │ • Direct Advice Reply │
│ • 4-Week Pilot Scope  │ • Possibility Results  │ • Status Resolver     │
│ • Safety Statement    │ • Speech Audio Readout │ • Knowledge Base Audit│
│ • FAQ & Contact Form  │ • "My Cases" & Sync    │ • Reviewed-By Tagger  │
└───────────────────────┴────────────────────────┴───────────────────────┘
```

1. **Public Project Website (`/`)**:
   - Clean, fast, accessible landing site communicating the pilot project.
   - Honest contextual grounding: Citing the 2015-16 Agriculture Census (86% of operational holdings in Assam are $< 2$ hectares).
   - Clear disclosure of the 4-week, 1-crop (Wheat), 1-district (Nagaon) testing phase with zero inflated impact claims.
   - Interactive 4-step visual explanation, core design principles, safety and data privacy manifesto, FAQ accordion, and inquiry contact form connecting to Firestore.
   - Universal language selector accessible in the header at all times.

2. **Farmer Progressive Web App (`/app`)**:
   - **Language Selection**: Assamese (অসমীয়া), Hindi (हिन्दी), English.
   - **Crop Selector**: Wheat highlighted with visual card; other regional crops (Rice, Mustard, Tea) clearly badged as *"Coming Later"*.
   - **Photo Upload**: Direct camera capture or gallery picker with real-time client-side HTML Canvas image compression ($\sim 150\text{KB}$ payload limit).
   - **Guided Diagnostics**: 4 to 8 plain-language symptom questions with clear Yes / No / Not Sure button cards ($\ge 48\text{px}$ touch targets).
   - **Possibility Result View**:
     - 1 to 3 candidate causes with High/Medium/Low confidence badges and matched symptom breakdown.
     - Bold advisory disclaimer: *"This is a possibility, not a final diagnosis."*
     - Clear agronomic next steps (cultural practices, preventive drainage, and non-commercial botanical options prioritized).
     - One-tap Web Speech API audio synthesis reading out recommendations in the chosen language.
     - "Ask an Agriculture Expert" escalation CTA.
   - **"My Cases" Drawer**: Displays historical submissions stored locally in Dexie.js and synced with Firestore, featuring live sync badges (`Saved on phone`, `Syncing`, `Sent`, `Expert replied`) and expandable officer advice threads.

3. **Expert Dashboard (`/expert`)**:
   - Google Sign-In with verified extension officer authorization check.
   - **Case Review Queue**: Filter by status (`Escalated`, `In Review`, `Resolved`), sort by submission timestamp, view farmer's uploaded photo, reported answers, and rule-engine confidence breakdown.
   - **Advisory Response Composer**: Direct text advice editor submitting back to the farmer's case with real-time notification sync.
   - **Knowledge Base Reviewer**: View and verify causes, rules, and safety steps, updating `reviewedBy` and `reviewedOn` audit tags.

### Visual Identity & Theme

- **Aesthetic Direction**: Calm, utilitarian agricultural elegance. Organic warmth, high contrast for outdoor sunlight readability, and clutter-free typography.
- **Color Palette**:
  - Dominant Canvas (60%): `#FBFBFA` (soft parchment white) and `#F4F4F0` (light card background).
  - Structural Surfaces (30%): `#1E3A2F` (deep Brahmaputra forest green) for headers, primary cards, and typography anchors; `#E2E8F0` for subtle hairline dividers.
  - Accent Budget (10%): `#D97706` / `#B45309` (Assam warm ochre/mustard) for focused states, progress steps, and active interactive controls.
- **Typography**:
  - Assamese: `Noto Sans Bengali` (full native glyph coverage).
  - Hindi: `Noto Sans Devanagari`.
  - English: `Plus Jakarta Sans` / `Inter`.
- **Touch & Ergonomics**:
  - All interactive buttons and selector cards maintain at least $48 \times 48\text{px}$ touch targets.
  - Zero-pill metadata discipline: dates, statuses, and categories use unboxed typography with dot separators (`·`).
  - Sticky elements adhere strictly to the $\le 15\%$ mobile viewport height cap.

---

## 3. Key Product Decisions & Trade-Offs

### Decision 1: Rule-Based Heuristic Matrix vs. Standalone Machine Learning
- **Chosen Approach**: A transparent, weighted Bayesian-style symptom matrix configured in JSON/Firestore, paired with an extensible `classifyImage(photo)` hook returning `[]` for pilot phase 1.
- **Why**: Zero hallucinations, 100% explainable symptom matching for agricultural officers, zero server GPU latency, and full offline execution on low-cost Android phones.
- **Alternatives Considered**: Direct on-device TensorFlow Lite model. Rejected for initial pilot because models without ground-truth local validation can hallucinate dangerous pesticide advice.

### Decision 2: Dual Storage (Dexie.js IndexedDB + Firestore Sync Engine)
- **Chosen Approach**: Save all farmer cases, diagnostic answers, and compressed photos immediately to IndexedDB via Dexie.js. A background sync engine listens to network transitions (`useOnlineStatus`) and replicates unsynced cases to Firestore.
- **Why**: Ensures 100% data reliability even if the farmer loses cellular connectivity while standing in the middle of a field.

### Decision 3: Split Authentication Tiers
- **Chosen Approach**: Anonymous Firebase Auth + local phone number entry for farmers; standard Google Sign-In with Firestore RBAC for experts and KVK agronomists.
- **Why**: Zero barrier to entry for smallholder farmers; verified Google credentials protect the expert advisory portal.

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌────────────────────────────────────────────────────────────────────────┐
│                        CLIENT RUNTIME (VITE PWA)                       │
├────────────────────────────────────────────────────────────────────────┤
│  [ i18n Engine: as-IN / hi-IN / en-IN ]  [ Web Speech Synthesis API ]  │
│  [ PWA Service Worker (CacheFirst)   ]  [ Network Watcher Status     ]  │
├────────────────────────────────────────────────────────────────────────┤
│                               VIEWS                                    │
│   / (Public Landing)     /app (Farmer Workflow)     /expert (Dashboard)│
│   • Assam Census Stats   • Crop Select [Wheat]      • Escalated Queue  │
│   • 4-Step Diagram       • Image Compress (~150KB)  • Case Inspection  │
│   • Safety Principles    • 4-8 Icon Questions       • Advice Composer  │
│   • Contact Submission   • Rule Diagnosis Engine    • KB Audit Matrix  │
│                          • "My Cases" Case Feed                        │
├────────────────────────────────────────────────────────────────────────┤
│                           DATA & STATE                                 │
│  ┌─────────────────────────┐               ┌────────────────────────┐  │
│  │ Local Storage (Offline) │ ◄─ Auto Sync ─► Auth & Firestore Cloud │  │
│  │ Dexie.js (IndexedDB)    │               │ Anonymous (Farmer)     │  │
│  │ • local_cases           │               │ Google Auth (Expert)   │  │
│  │ • cached_knowledge_base │               │ Collections: cases,    │  │
│  │ • pending_sync_queue    │               │ knowledgeBase, replies │  │
│  └─────────────────────────┘               └────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘
```

### Firestore Schema Blueprint (`firebase-blueprint.json`)

1. `users/{userId}`: `role` ('farmer' | 'expert'), `phone`, `preferredLanguage`, `createdAt`.
2. `cases/{caseId}`: `userId`, `crop` ('wheat'), `photoBase64`, `answers` (map of questionId to 'yes'|'no'|'not_sure'), `result` (causes, confidence, matchedSymptoms), `status` ('saved_locally' | 'syncing' | 'sent' | 'expert_replied'), `createdAt`, `updatedAt`.
3. `expertReplies/{replyId}`: `caseId`, `expertId`, `expertName`, `guidanceText`, `createdAt`.
4. `crops/{cropId}`: `name`, `scientificName`, `pilotActive`, `icon`.
5. `causes/{causeId}`: `cropId`, `name`, `assameseName`, `hindiName`, `description`, `riskLevel` ('low' | 'medium' | 'high').
6. `questions/{questionId}`: `cropId`, `order`, `text`, `assameseText`, `hindiText`, `icon`.
7. `rules/{ruleId}`: `questionId`, `causeId`, `weight`.
8. `nextSteps/{stepId}`: `causeId`, `text`, `assameseText`, `hindiText`, `riskLevel`, `reviewedBy`, `reviewedOn`.
9. `contactMessages/{messageId}`: `name`, `email`, `subject`, `message`, `createdAt`.

### Security Rules Architecture (`firestore.rules`)
- **Default Deny**: `match /{document=**} { allow read, write: if false; }`.
- **Farmers**: Can create and read only their own `cases/{caseId}` (`resource.data.userId == request.auth.uid`).
- **Experts**: Identified via `exists(/databases/$(database)/documents/experts/$(request.auth.uid))` or admin document; can read all escalated cases and create verified `expertReplies`.
- **Knowledge Base (`crops`, `causes`, `questions`, `rules`, `nextSteps`)**: Publicly readable by authenticated farmers; strictly writable only by verified experts.
- **Contact Messages**: Create-only for public submissions with field and length validation; readable only by administrators.

---

## 5. Staged Implementation Roadmap

Following your required build order:

- **Stage 1: Design System, i18n, Routing & Public Website**
  - Implement calm agricultural design system with Tailwind CSS (Forest Green, Warm Ochre, Off-White).
  - Setup multi-language support (`react-i18next`) supporting Assamese, Hindi, and English with immediate switching.
  - Build responsive public landing site at `/` highlighting Nagaon pilot scope, 2015-16 Agriculture Census data, 4-step workflow, 6 design principles, and contact form.
- **Stage 2: Farmer Mobile Workflow with Dexie.js & Heuristic Engine**
  - Construct `/app` route: crop selection, HTML5 client-side camera/gallery upload with canvas compression ($\sim 150\text{KB}$).
  - Implement 4–8 guided visual question cards with Yes / No / Unsure buttons.
  - Implement transparent rule-based diagnosis engine calculating candidate cause confidence and flagging escalations.
  - Build result screen with confidence levels, safe cultural next steps, Web Speech API audio narration, and Dexie.js local storage.
- **Stage 3: Firebase Integration (Auth, Firestore, Sync Engine & Security Rules)**
  - Execute `set_up_firebase` tool workflow.
  - Wire Anonymous Authentication for farmers and Google Sign-In for experts.
  - Build background sync manager connecting IndexedDB to Firestore with 4 status badges.
  - Generate and deploy hardened `firestore.rules` adhering to the 8 security pillars.
- **Stage 4: Progressive Web App (PWA) Offline Caching**
  - Install `vite-plugin-pwa` and configure Workbox service worker caching app shell, i18n locales, and symptom dataset.
  - Generate compliant PWA Web App Manifest, 192x192 / 512x512 icons, and in-app install banner with iOS Safari support.
- **Stage 5: Expert Advisory Dashboard**
  - Build `/expert` portal with Google Auth and officer verification.
  - Case escalation queue with filter tabs, photo zoom, question audit, and direct advisory response composer.
  - Knowledge base audit view showing "Reviewed by" and "Reviewed on" timestamps.
- **Stage 6: Knowledge Base Seed & Data Import Utility**
  - Seed vetted Nagaon wheat diseases (Stripe Rust, Brown Rust, Karnal Bunt, Powdery Mildew, Nutrient Deficiencies).
  - Provide admin import utility for CSV/JSON files with schema validation guidelines.

---

## 6. Completed Futuristic AgriTech UI/UX Transformation

- [x] **Visual Identity & Color System**: Upgraded to deep forest green (`#071C16`), dark botanical green (`#0C2A20`), elevated card surfaces (`#12372A`), electric lime accents (`#B8F34A`), and soft mint (`#B8E6C8`) in `index.html` and `src/index.css`.
- [x] **Typography & Anti-Slop Discipline**: Paired Manrope and Inter display fonts with Noto Sans Bengali (`as`) and Noto Sans Devanagari (`hi`). Applied zero-pill metadata formatting (`·`), balanced headlines, and clear visual hierarchy.
- [x] **Homepage Hero & Preview HUD**: Built an asymmetric editorial hero with atmospheric botanical lighting, live crop-health diagnostic preview HUD with botanical graphics, 85.6% Assam Census statistics banner, 4-step workflow cards, 6 core principles, and verified safety manifesto.
- [x] **Farmer Diagnostic Experience**: Equipped `FarmerApp.tsx` with high-contrast touch targets ($\ge 48\text{px}$ for Yes / No / Not Sure), image dropzone with field compression, speech synthesis read-aloud button, and offline IndexedDB case records with status indicators.
- [x] **Agronomic Officer Console**: Styled `ExpertDashboard.tsx` with case review filters, photo inspection modal with zoom, transparent rules score breakdown, reply transmitter, certified knowledge base guidelines, and CSV/JSON schema importer.
- [x] **Build & Quality Assurance**: Completed full verification with zero lint or compilation errors (`lint_applet` and `compile_applet` passed).
